/* Defines a MFP dictionary
 * Copyright (C) 2017 Laboratory of Computational Biology, Monash University
 * (http://lcb.infotech.monash.edu.au)
 *
 * Reference:
 *   J. H. Collier, L. Allison, A. M. Lesk, P.J. Stuckey,
 *   M. Garcia de la Banda, A. S. Konagurthu.
 *   Bioinformatics 33(7):1005-1013, 2017.
 *
 * MMLigner is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MMLigner is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MMLigner. If not, see <http://www.gnu.org/licenses/>.
 */


#include "dictClass.h"

dictClass_t::dictClass_t() {
  dictionaryMsgLen = 0 ;
  nDictElem =  0 ;
}

void dictClass_t::pop_back() {
   dictElem.pop_back() ;
   dictElemLegend.pop_back() ;
   dictElemMsgLen.pop_back() ;
}

void dictClass_t::erase( const size_t indx ) {
    vector<vector< vector<float> > >::iterator dictIter ;
    vector<vector<size_t> >::iterator dictElemLegendIter ;
    vector<double>::iterator dictElemMsgLenIter ;
    size_t cnt = 0;
  
    //remove from dictElem
    for (dictIter  = dictElem.begin(); 
         dictIter != dictElem.end(); 
         dictIter++, cnt++ ) {

         if (cnt == indx) {
             dictElem.erase (dictIter) ;
             break ;
         }
    }

    //remove from dictElemLegend
    cnt = 0 ;
    for (dictElemLegendIter = dictElemLegend.begin(); 
         dictElemLegendIter != dictElemLegend.end(); 
         dictElemLegendIter++, cnt++ ) {
         if (cnt == indx) {
             dictElemLegend.erase (dictElemLegendIter) ;
             break ;
         }
    }

    //remove from model statement cost vector
    cnt = 0 ;
    for( dictElemMsgLenIter=dictElemMsgLen.begin();
         dictElemMsgLenIter != dictElemMsgLen.end(); 
         dictElemMsgLenIter++, cnt++ ) {
         if( cnt == indx ) {
             dictElemMsgLen.erase (dictElemMsgLenIter) ;
             break ;
        }
    }
}

void dictClass_t::add(
  const vector<vector<float> > &frag,
  const vector<size_t> &loci // vector with struct, 
                       // start and end point indexes
) {
    dictElem.push_back(frag) ;
    dictElemLegend.push_back(loci) ;

    double len = getMsgLenNullModel(frag) ;

    dictElemMsgLen.push_back(len) ;
    dictionaryMsgLen += len ;

    nDictElem++ ;
    assert(msgLenSanityCheck()) ;
}

void dictClass_t::remove( const size_t indx ) {
    assert( indx < nDictElem ) ;
   
   double len = dictElemMsgLen[indx] ;
   dictionaryMsgLen -= len ;
    if( indx == nDictElem-1 ) { // last element, simply pop_back() 
        pop_back();
    }
    else { // erase with iterators
        erase(indx) ;
    }
    nDictElem-- ;
    assert(msgLenSanityCheck()) ;
}

void dictClass_t::swap(
  const vector<vector<float> > &dictElem, // coords of dictElem to add
  const vector<size_t> &loci, // loci of the coords to be added
  const size_t indx // index of dictElem element to be swapped OUT
) {
    remove(indx) ;
    add(dictElem, loci) ;
}

double dictClass_t::getDictionaryMsgLen(){
  return dictionaryMsgLen ;
}

size_t dictClass_t::size() {
    return nDictElem ;
}

size_t dictClass_t::pickRandElem(
  vector<vector<float> > &elem,  
  vector<size_t> &loci 
) {
   assert(nDictElem > 0 ) ;
   // pick a random indx in the range [0,nDictElem]
   size_t r = rand()%nDictElem ;
   
   elem = dictElem[r] ;
   loci = dictElemLegend[r] ;
   return r ;
}

void dictClass_t::printLegend(
  vector<string> &structNames 
) {
    cout << "### Current Dictionary ###" << endl ;
    for ( size_t i = 0 ; i < nDictElem ; i++ ) {
          cout << structNames[dictElemLegend[i][0]] << " "
               << setw(5) <<  dictElemLegend[i][1] << " " 
               << setw(5) <<  dictElemLegend[i][2]<< " |len = " 
               << setw(3) <<  dictElemLegend[i][2]- dictElemLegend[i][1]+1 
               << endl;
    }
    cout << endl ;
}

void dictClass_t::printDictElemLegend(
  vector<string> &structNames,
  size_t indx
) {
    cout << structNames[dictElemLegend[indx][0]] << " "
         << setw(5) <<  dictElemLegend[indx][1] << " " 
         << setw(5) <<  dictElemLegend[indx][2]<< " |len = " 
         << setw(3) <<  dictElemLegend[indx][2]- dictElemLegend[indx][1]+1 << flush ;
}

void dictClass_t::printLastElemLegend(
  vector<string> &structNames
) {
    size_t indx = nDictElem-1 ;
    cout << structNames[dictElemLegend[indx][0]] << " "
         << setw(5) <<  dictElemLegend[indx][1] << " " 
         << setw(5) <<  dictElemLegend[indx][2]<< " |len = " 
         << setw(3) <<  dictElemLegend[indx][2]- dictElemLegend[indx][1]+1 << flush ;
}

bool dictClass_t::msgLenSanityCheck() {
//cout << nDictElem << " " << dictElemMsgLen.size() << endl ;
    if( nDictElem != dictElemMsgLen.size() ) return 0 ;
/*
    float sum;
    for (size_t i = 0 ; i < nDictElem; i++ ) {
         sum += dictElemMsgLen[i] ;
    }
//cout << sum << " " << dictionaryMsgLen << endl ;
    if( sum-dictionaryMsgLen >=0.01  ) return 0 ;
    else if( sum-dictionaryMsgLen <=-0.01  ) return 0 ;
*/
    else return 1 ;

}
