/* Defines a command line interface and an API for reading argv
 * Copyright (C) 2017 Laboratory of Computational Biology, Monash University
 * (http://lcb.infotech.monash.edu.au)
 *
 * Reference:
 *   J. H. Collier, L. Allison, A. M. Lesk, P.J. Stuckey,
 *   M. Garcia de la Banda, A. S. Konagurthu.
 *   Bioinformatics 33(7):1005-1013, 2017.
 *
 * MMLigner is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MMLigner is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MMLigner. If not, see <http://www.gnu.org/licenses/>.
 */


#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <string>
#include <map>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cassert>
#include <stdint.h>
#include "misc.h"

using namespace std ;
void parseCmdLine( int , char *[],vector<string>&,vector<string>&, bool &, string&, bool &, string&);
