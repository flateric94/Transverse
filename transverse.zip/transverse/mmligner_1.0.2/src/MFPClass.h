/* Interface for dealing with maximal fragment pairs (MFPs)
 * Copyright (C) 2017 Laboratory of Computational Biology, Monash University
 * (http://lcb.infotech.monash.edu.au)
 *
 * Reference:
 *   J. H. Collier, L. Allison, A. M. Lesk, P.J. Stuckey,
 *   M. Garcia de la Banda, A. S. Konagurthu.
 *   Bioinformatics 33(7):1005-1013, 2017.
 *
 * MMLigner is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MMLigner is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MMLigner. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef MFPCLASS_H
#define MFPCLASS_H
#include<iostream>
#include<fstream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cassert>
#include<string>
#include<stdint.h>
#include<map>
#include<vector>
#include<sstream>
#include<time.h>
#include "structureInformationClass.h"
#include "superpose3D.h"
#include "misc.h"
using namespace std;
class MFPClass_t {
   public:
      bool             setflag;
      vector<size_t>   locus;
      size_t           length;
      vector<float>    coverage;
      float            score;
      float            rmsd;
      Superpose3DClass supobj;
      MFPClass_t();
};

class MFPLibraryClass_t{
   private:
      vector<MFPClass_t> mfpLibrary;
   public:
      vector<size_t> strsize;
      MFPLibraryClass_t();
      MFPLibraryClass_t(structureInformationClass &, structureInformationClass &);
      MFPLibraryClass_t(structureInformationClass &, structureInformationClass &, float, size_t);
      MFPLibraryClass_t(structureInformationClass &, structureInformationClass &, float, size_t, string);
      MFPLibraryClass_t(vector<MFPClass_t> &mfp, size_t, size_t);
      MFPLibraryClass_t(vector<vector<double> >, vector<vector<double> >, float, size_t);
      vector<MFPClass_t> getMFPLibrary();
      size_t getMFPLibrarySize();
      MFPClass_t getLargestMFP();
      void print(string);
};
#endif
