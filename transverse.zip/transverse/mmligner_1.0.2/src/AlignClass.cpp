/* Defines a generic pairwise alignment API
 * Copyright (C) 2017 Laboratory of Computational Biology, Monash University
 * (http://lcb.infotech.monash.edu.au)
 *
 * Reference: 
 *   J. H. Collier, L. Allison, A. M. Lesk, P.J. Stuckey,
 *   M. Garcia de la Banda, A. S. Konagurthu.
 *   Bioinformatics 33(7):1005-1013, 2017.
 *
 * MMLigner is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MMLigner is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MMLigner. If not, see <http://www.gnu.org/licenses/>.
 */

#include "AlignClass.h"
float mymax(vector<float> arr, size_t &indx) {
   float maxval = arr[0];
   indx = 0;
   for (size_t i = 1; i < 3; i++) {
      if (arr[i] > maxval) {
         maxval = arr[i];
         indx = i;
      }
   }
   return maxval;
}


AlignClass_t::AlignClass_t(vector<vector<float> > &w) {
   dprows = w.size()+1;    // including dummy
   dpcols = w[0].size()+1; // including dummy

   for (size_t i = 0 ; i < dprows; i++) {
      dp.push_back(vector<float>(dpcols,0));
      hist.push_back(vector<uint8_t>(dpcols,0));
   }

   for (size_t i = 1; i < dprows; i++) {
      hist[i][0] = 1; 
   }
   for (size_t j = 1; j < dpcols; j++) {
      hist[0][j] = 2; 
   }

   for (size_t i = 1; i < dprows; i++) {
      for (size_t j = 1; j < dpcols; j++) {
         //cout << i << " " << j << endl;
         vector<float> arr(3,0);

         arr[0]   = dp[i-1][j-1] + w[i-1][j-1];
         arr[1]   = dp[i-1][j];
         arr[2]   = dp[i][j-1];
         size_t indx = -1;
         dp[i][j] = mymax(arr, indx);
         assert(indx < 3);
         hist[i][j] = indx;
      }
   }
}

string AlignClass_t::getFSAString() {
   size_t i, j;
   string fsastring;
   i = dprows-1;
   j = dpcols-1;
   assert (i < dprows && j < dpcols);
   while (i > 0 || j > 0) {
      switch(hist[i][j]) {
         case 0: fsastring.push_back('m');
                 i--; j--;
                 break;
         case 1: fsastring.push_back('d');
                 i--; 
                 break;
         case 2: fsastring.push_back('i');
                 j--;
                 break;
      }
   }
   reverse(fsastring.begin(), fsastring.end());
   return fsastring;
}

vector<vector<float> > AlignClass_t::getDPMatrix(){
   return dp;
}

vector<size_t> AlignClass_t::getDimensions() {
   vector<size_t> tmp ;
   tmp.push_back(dprows);
   tmp.push_back(dpcols);
   return tmp;
}
