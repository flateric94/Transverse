/* I-value implementation
 * Copyright (C) 2017 Laboratory of Computational Biology, Monash University
 * (http://lcb.infotech.monash.edu.au)
 *
 * Reference:
 *   J. H. Collier, L. Allison, A. M. Lesk, P.J. Stuckey,
 *   M. Garcia de la Banda, A. S. Konagurthu.
 *   Bioinformatics 33(7):1005-1013, 2017.
 *
 * MMLigner is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MMLigner is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MMLigner. If not, see <http://www.gnu.org/licenses/>.
 */

#include "mmligner_config.h"
#include "ivalue.h"

double logStarNew_bits( const size_t n ) {
	assert(n>0) ;

	// normalizing constant thanks to lloyd!
	double norm_const = log(2.865)/log(2) ; 
	if ( n == 1 ) return norm_const ;

	double val = log(n)/log(2) ;
	double prev = val ;

	while( val >= 0 ) {
		double t = log(prev)/log(2);
		if( t <= 0 ) break ;
		val += t ;
		prev = t ;
	}	
	double bitlen = val+norm_const ;
    return bitlen ;
}

double logStarNew_nits(const size_t n) {
    double msglen = logStarNew_bits(n);
    return bits2nits(msglen);
}

/* negative log prob of x over a normal distribution */
double negLogProbNormalDist(
  const double x,  // datum
  const double mu, // mean
  const double sd, // standard deviation
  double eps       // accuracy of measurement
) {
   // Pr = eps/[sqrt(2*pi)*sd] exp(-0.5*(x-mu)^2/sd^2)
   return log(sqrt(2*M_PI)*sd) + ((x-mu)*(x-mu))/(2*sd*sd) - log(eps) ;
}


/* cost to state a cell num of area AOM^2 on the surface of 
   a sphere with radius r */
double negLogProbUniformDirection(
  const double rad,
  const double eps
) {
      return  log(4*M_PI*rad*rad) - 2*log(eps) ;
}

/* Given (x,y,z) CA coordinates of a
   tetramer:  A, B, C, D
   compute direction cosines of vector CD
   s.t.
   A is in the -veX and +veY quadrant.
   B is on the -ve X axis
   C is the origin
   D is the one that is being encoded
*/
vector<double> canonicalize(
 double A[3], double B[3],
 double C[3], double D[3]
) {
    double AB[3], BC[3], CD[3];
    computeVectorDifference(B,A,AB);
    computeVectorDifference(C,B,BC);
    computeVectorDifference(D,C,CD);

    double unitCD[3];
    computeDirectionCosines(CD,unitCD);

    double zenith[3];                 // z-axis when actually transformed
    computeNormal(AB,BC,zenith);
   
    /* compute theta in the range 0 to pi */
    double dp;
    computeDotProduct(zenith,unitCD,dp);
    if (dp > 1) dp =1;
    if (dp < -1) dp=-1;
    double theta = acos(dp); 

    /* compute phi in the range -pi to pi */
    double horizontal[3];             // x-axis when actually transformed
    computeDirectionCosines(BC,horizontal);

    double zenith_cross_horizontal[3];// y-axis when actually transformed
    computeNormal(zenith,horizontal,zenith_cross_horizontal);
   
    double origin[3] = {0,0,0};
    double proj[3];
    projectPoint2Plane(
            unitCD,origin,horizontal,zenith_cross_horizontal,proj);
    double unit_proj[3];
    computeDirectionCosines(proj,unit_proj);
    computeDotProduct(unit_proj,horizontal,dp);
    if (dp > 1) dp =1;
    if (dp < -1) dp=-1;
    double phi = acos(dp);
    double sign = 0.0 ;
    computeBoxProduct(zenith,horizontal,unit_proj,sign);
    phi = (sign > 0)?phi:-phi;

    /* prepare to return */
    vector<double> xi(3);
    xi[0] = sin(theta)*cos(phi);
    xi[1] = sin(theta)*sin(phi);
    xi[2] = cos(theta);

    //cout << theta*180/M_PI << " " << phi*180/M_PI << endl;

    return xi;
}


double computeKentLikelihood(vector<double> xi, KentComponent kc, double eps) {
    double kappa = kc.kappa;
    double beta  = kc.beta;
    double log_norm_const = kc.log_norm_const;
    double gamma1[3],gamma2[3],gamma3[3]; // mean, major, minor

    gamma1[0] = kc.mean.x;  gamma1[1] = kc.mean.y;  gamma1[2] = kc.mean.z;
    gamma2[0] = kc.major.x; gamma2[1] = kc.major.y; gamma2[2] = kc.major.z;
    gamma3[0] = kc.minor.x; gamma3[1] = kc.minor.y; gamma3[2] = kc.minor.z;


    double x[3];
    x[0] = xi[0]; x[1] = xi[1]; x[2] = xi[2];

    double dp1, dp2, dp3;
    computeDotProduct(gamma1,x,dp1);
    computeDotProduct(gamma2,x,dp2);
    computeDotProduct(gamma3,x,dp3);

    double loglikelihood;
    loglikelihood = kappa*dp1 + beta*(dp2*dp2-dp3*dp3)
                    + 2*log(eps) - log_norm_const ;
    //cout << "likelihood = " << exp(loglikelihood) << endl;
    return exp(loglikelihood); // return likelihood.
}

CACoordinateEncoding_t::CACoordinateEncoding_t(vector<vector<double> > C, KentMixtureModel  &kent) {
    dim = C.size();
    for (size_t i = 0; i < C.size(); i++) {
        double ri = 0;
        // Remember for each C[i], its likelihood for each component
        // in the kent mixture
        vector<double> likelihoods(kent.componentCount(),0); 
        // Handle first three points as a special case 
        if (i == 0) {
            Iradius.push_back(0);
            IThetaPhi.push_back(0);
            kent_likelihoods.push_back(likelihoods);
        }
        else {
            /* encode radius ri and store the encoding length*/
            double xi[3];
            xi[0] = C[i][0]-C[i-1][0];
            xi[1] = C[i][1]-C[i-1][1];
            xi[2] = C[i][2]-C[i-1][2];
            ri = vectorNorm(xi); 
            if (ri > 4) ri = 4;
            if (ri < 3.6) ri = 3.6;
            Iradius.push_back(negLogProbNormalDist(ri,3.8,0.4,AOM)); 
            
            if (i < 3) // encode direction on a uniform sphere and store
                IThetaPhi.push_back(negLogProbUniformDirection(ri,AOM));
            else { // encode direction using Kent mixture model and store
                //prepare tetramer 
                double P1[3], P2[3], P3[3], P4[3];
                P1[0] = C[i-3][0]; P1[1] = C[i-3][1]; P1[2] = C[i-3][2];
                P2[0] = C[i-2][0]; P2[1] = C[i-2][1]; P2[2] = C[i-2][2];
                P3[0] = C[i-1][0]; P3[1] = C[i-1][1]; P3[2] = C[i-1][2];
                P4[0] = C[i][0];   P4[1] = C[i][1];   P4[2] = C[i][2];
                vector<double> ci = canonicalize(P1,P2,P3,P4);

                double pr = 0;
                for (size_t j = 0; j < kent.componentCount(); j++) {
                    KentComponent kc(kent.component(j));
                    double eps = (double)AOM/ri;
                    likelihoods[j] = computeKentLikelihood(ci,kc,eps);
                    pr += (kc.weight*likelihoods[j]);
                }
                IThetaPhi.push_back(-log(pr));
            }
            kent_likelihoods.push_back(likelihoods);
        }
                    
        if (VERBOSE) {
            cout << "i = " << i << "; I(dir)=" 
                << setw(7) << setprecision(3) << fixed 
                << nits2bits(IThetaPhi[i]) << "+I(rad)=" 
                << setw(7) << setprecision(3) << fixed 
                << nits2bits(Iradius[i])    << " = " 
                << setw(7) << setprecision(3) << fixed 
                << nits2bits(IThetaPhi[i]+Iradius[i])
                << " bits| radius = " << ri << endl;
        }
    }
    //exit(0);
}

double CACoordinateEncoding_t::getIThetaPhi(size_t indx) {
    return IThetaPhi[indx];
}

double CACoordinateEncoding_t::getIRadius(size_t indx) {
    return Iradius[indx];
}


double CACoordinateEncoding_t::getIThetaPhiRadius(size_t indx) {
    return IThetaPhi[indx]+Iradius[indx];
}

double CACoordinateEncoding_t::getIThetaPhiRadius() {
    double msglen = 0;
    for (size_t i = 0; i < dim; i++) {
        msglen += IThetaPhi[i]+Iradius[i];
    }
    return msglen; 
}

double CACoordinateEncoding_t::getNullModelMessageLength() {
    double msglen = getIThetaPhiRadius();
    msglen += logStarNew_nits(dim+1);
    return msglen;
}

vector<double> CACoordinateEncoding_t::getComponentLikelihoods(size_t indx) {
    assert(indx < dim);
    return kent_likelihoods[indx];
}

double CACoordinateEncoding_t::getReweightedIThetaPhiRadius(
  size_t target_indx, 
  vector<double> &src_likelihoods, 
  KentMixtureModel &kent) {
    vector<double> weights(kent.componentCount(),0); 
    double cummul_weight = 0;
    for (size_t j = 0; j < kent.componentCount(); j++) {
        KentComponent kc(kent.component(j));
        weights[j] = kc.weight*src_likelihoods[j];
        cummul_weight += weights[j];
    }
    //normalize weights and compute probability
    double pr = 0;
    for (size_t j = 0; j < kent.componentCount(); j++) {
        weights[j] /= cummul_weight;
        pr += (weights[j]*kent_likelihoods[target_indx][j]);
    }
    double newIthetaPhi = -log(pr);
    return (newIthetaPhi+Iradius[target_indx]);
}

double computeIA(string fsastr,vector<double> &IAbreakdown) {
    size_t nI_left, nD_left, nI_right, nD_right;
    nI_left = nI_right = nD_left = nD_right = 0;
    size_t mSP = 0, mEP = 0; // start and end point of 'm' state
    //left terminal nIs and nDs
    for (size_t i = 0; i < fsastr.size(); i++) {
        if (fsastr[i] == 'm'){
            mSP = i;
            break;
        }
        else if (fsastr[i] == 'i') nI_left++;
        else nD_left++;
    }
    for (ssize_t i = fsastr.size()-1; i >= 0; i--) {
        if (fsastr[i] == 'm') {
            mEP = i;
            break;
        }
        else if (fsastr[i] == 'i') nI_right++;
        else nD_right++;
    }
    double IA = 0;
    //cout << nI_left << " " << nD_left << ", " << nI_right << " " << nD_right << endl; 
    IA += logStarNew_nits(nI_left+1) ;
    IA += logStarNew_nits(nD_left+1) ;
    IA += logStarNew_nits(nI_right+1) ;
    IA += logStarNew_nits(nD_right+1) ;
    double part = 0;
                          /*         m  i  d sum  */
    double cntrs[3][4] = {/* m */ {  1, 1, 1, 3   },
                          /* i */ {  1, 1, 1, 3   },       
                          /* d */ {  1, 1, 1, 3   } };       
    
    part = 0; // encoding first symbol -- uniform
    IA = part; 
    IAbreakdown.push_back(part);
    char prev = fsastr[0];
    for (size_t i = 1; i < fsastr.length(); i++) {
        char curr = fsastr[i];
        if (i <= mSP || i >= mEP) IAbreakdown.push_back(0);
        else {
            if (prev == 'm' && curr == 'm') {
                part = -log(cntrs[0][0]++/cntrs[0][3]++);
            }
            else  if (prev == 'm' && curr == 'i') {
                part = -log(cntrs[0][1]++/cntrs[0][3]++);
            }
            else  if (prev == 'm' && curr == 'd') {
                part = -log(cntrs[0][2]++/cntrs[0][3]++);
            }
            else if (prev == 'i' && curr == 'm') {
                part = -log(cntrs[1][0]++/cntrs[1][3]++);
            }
            else  if (prev == 'i' && curr == 'i') {
                part = -log(cntrs[1][1]++/cntrs[1][3]++);
            }
            else  if (prev == 'i' && curr == 'd') {
                part = -log(cntrs[1][2]++/cntrs[1][3]++);
            }
            else if (prev == 'd' && curr == 'm') {
                part = -log(cntrs[2][0]++/cntrs[2][3]++);
            }
            else  if (prev == 'd' && curr == 'i') {
                part = -log(cntrs[2][1]++/cntrs[2][3]++);
            }
            else  if (prev == 'd' && curr == 'd') {
                part = -log(cntrs[2][2]++/cntrs[2][3]++);
            }
            
            IA += part; 
            IAbreakdown.push_back(part);
        }
        prev = curr;
    }
    part = logStarNew_nits(fsastr.size());
    IA += part; // cost of stating length 
    return IA;
}

double computeIAnewSymmetric(string fsastr,vector<double> &IAbreakdown) {
    size_t nI_left, nD_left, nI_right, nD_right;
    nI_left = nI_right = nD_left = nD_right = 0;
    ssize_t mSP = -1, mEP = -1; // start and end point of 'm' state
    //left terminal nIs and nDs
    for (size_t i = 0; i < fsastr.size(); i++) {
        if (fsastr[i] == 'm'){
            mSP = i;
            break;
        }
        else if (fsastr[i] == 'i') nI_left++;
        else if (fsastr[i] == 'd') nD_left++;
    }
    if (mSP >= 0) {
        for (ssize_t i = fsastr.size()-1; i >= 0; i--) {
            if (fsastr[i] == 'm') {
                mEP = i;
                break;
            }
            else if (fsastr[i] == 'i') nI_right++;
            else if (fsastr[i] == 'd') nD_right++;
        }
    }
    else {
        mSP = fsastr.size();
        nI_right = nD_right = 0;
    }
    double IA = 0;
    IA += logStarNew_nits(nI_left+1) ;
    IA += logStarNew_nits(nD_left+1) ;
    IA += logStarNew_nits(nI_right+1) ;
    IA += logStarNew_nits(nD_right+1) ;
    double part = 0;
                          /*         m  i  d sum  */
    double cntrs[3][4] = {/* m */ {  1, 1, 1, 3   },
                          /* i */ {  1, 1, 1, 3   },       
                          /* d */ {  1, 1, 1, 3   } };       
    
    part = 0; // encoding first symbol -- uniform
    IA += part; 
    IAbreakdown.push_back(part);
    char prev = fsastr[0];
    for (size_t i = 1; i < fsastr.length(); i++) {
        char curr = fsastr[i];
        if (curr == '|') continue;
        if (static_cast<ssize_t>(i) <= mSP || static_cast<ssize_t>(i) >= mEP)  continue;
        else {
            if (prev == 'm' && curr == 'm')       { cntrs[0][0]++; cntrs[0][3]++;}
            else  if (prev == 'm' && curr == 'i') { cntrs[0][1]++; cntrs[0][3]++;}
            else  if (prev == 'm' && curr == 'd') { cntrs[0][2]++;  cntrs[0][3]++;}
            else if (prev == 'i' && curr == 'm')  { cntrs[1][0]++;  cntrs[1][3]++;}
            else  if (prev == 'i' && curr == 'i') { cntrs[1][1]++;  cntrs[1][3]++;}
            else  if (prev == 'i' && curr == 'd') { cntrs[1][2]++;  cntrs[1][3]++;}
            else if (prev == 'd' && curr == 'm')  { cntrs[2][0]++;  cntrs[2][3]++;}
            else  if (prev == 'd' && curr == 'i') { cntrs[2][1]++;  cntrs[2][3]++;}
            else  if (prev == 'd' && curr == 'd') { cntrs[2][2]++;  cntrs[2][3]++;}
        }
        prev = curr;
    }
    prev = fsastr[0];
    part = 0;

    //enforce symmetry
    // pr m->i = pr m->d
    cntrs[0][1] = (cntrs[0][1]+cntrs[0][2])/2;
    cntrs[0][2] = cntrs[0][1];
    //pr i->m = pr d->m
    cntrs[1][0] = (cntrs[1][0]+cntrs[2][0])/2;
    cntrs[2][0] = cntrs[1][0];
    //pr i->d = pr d->i
    cntrs[1][2] = (cntrs[1][2]+cntrs[2][1])/2;
    cntrs[2][1] = cntrs[1][2];
    //pr i->i = pr d->d
    cntrs[1][1] = (cntrs[1][1]+cntrs[2][2])/2;
    cntrs[2][2] = cntrs[1][1];
    //update counters
    cntrs[0][3] = cntrs[0][0]+cntrs[0][1]+cntrs[0][2];
    cntrs[1][3] = cntrs[1][0]+cntrs[1][1]+cntrs[1][2];
    cntrs[2][3] = cntrs[2][0]+cntrs[2][1]+cntrs[2][2];



    for (size_t i = 1; i < fsastr.length(); i++) {
        char curr = fsastr[i];
        if (static_cast<ssize_t>(i) <= mSP
            || static_cast<ssize_t>(i) >= mEP || curr == '|') {
          IAbreakdown.push_back(0);
        } else {
            if (prev == 'm' && curr == 'm') {
                part = -log(cntrs[0][0]/cntrs[0][3]);
            }
            else  if (prev == 'm' && curr == 'i') {
                part = -log(cntrs[0][1]/cntrs[0][3]);
            }
            else  if (prev == 'm' && curr == 'd') {
                part = -log(cntrs[0][2]/cntrs[0][3]);
            }
            else if (prev == 'i' && curr == 'm') {
                part = -log(cntrs[1][0]/cntrs[1][3]);
            }
            else  if (prev == 'i' && curr == 'i') {
                part = -log(cntrs[1][1]/cntrs[1][3]);
            }
            else  if (prev == 'i' && curr == 'd') {
                part = -log(cntrs[1][2]/cntrs[1][3]);
            }
            else if (prev == 'd' && curr == 'm') {
                part = -log(cntrs[2][0]/cntrs[2][3]);
            }
            else  if (prev == 'd' && curr == 'i') {
                part = -log(cntrs[2][1]/cntrs[2][3]);
            }
            else  if (prev == 'd' && curr == 'd') {
                part = -log(cntrs[2][2]/cntrs[2][3]);
            }
            
            IA += part; 
            IAbreakdown.push_back(part);
        }
        prev = curr;
    }
    assert (IAbreakdown.size() == fsastr.length());
        /*
        //debug
        for(size_t k = 0 ; k < 3; k++) {
            for (size_t l = 0; l < 4; l++) {
                cout << setw(9) << setprecision(3) << fixed << cntrs[k][l];
            }
            cout << endl;
        }
        cout << "probabilities" << endl;
        for(size_t k = 0 ; k < 3; k++) {
            for (size_t l = 0; l < 4; l++) {
                cout << setw(9) << setprecision(3) << fixed << cntrs[k][l]/cntrs[k][3];
            }
            cout << endl;
        }
        */
    part = logStarNew_nits(fsastr.size()-nI_left-nI_right-nD_left-nD_right+1);
    IA += part; // cost of stating length 

    //statement cost of n rigid segments;
    size_t nRigidBlocks = getnRigidBlocks(fsastr); 
    IA +=  logStarNew_nits(nRigidBlocks); 
    //statement cost of positions;
    size_t nMatchBlocks = getnMatchBlocks(fsastr);
    if (nRigidBlocks > 1) IA += (nRigidBlocks-1)*log(nMatchBlocks+1);

    return IA;

}


double computeIAnew(string fsastr,vector<double> &IAbreakdown) {
    size_t nI_left, nD_left, nI_right, nD_right;
    nI_left = nI_right = nD_left = nD_right = 0;
    size_t mSP = 0, mEP = 0; // start and end point of 'm' state
    //left terminal nIs and nDs
    for (size_t i = 0; i < fsastr.size(); i++) {
        if (fsastr[i] == 'm'){
            mSP = i;
            break;
        }
        else if (fsastr[i] == 'i') nI_left++;
        else nD_left++;
    }
    for (ssize_t i = fsastr.size()-1; i >= 0; i--) {
        if (fsastr[i] == 'm') {
            mEP = i;
            break;
        }
        else if (fsastr[i] == 'i') nI_right++;
        else nD_right++;
    }
    double IA = 0;
    cout << nI_left << " " << nD_left << ", " << nI_right << " " << nD_right << endl; 
    IA += logStarNew_nits(nI_left+1) ;
    cout << nits2bits(IA) << endl;
    IA += logStarNew_nits(nD_left+1) ;
    cout << nits2bits(IA) << endl;
    IA += logStarNew_nits(nI_right+1) ;
    cout << nits2bits(IA) << endl;
    IA += logStarNew_nits(nD_right+1) ;
    cout << nits2bits(IA) << endl;
    double part = 0;
                          /*         m  i  d sum  */
    double cntrs[3][4] = {/* m */ {  1, 1, 1, 3   },
                          /* i */ {  1, 1, 1, 3   },       
                          /* d */ {  1, 1, 1, 3   } };       
    
    part = 0; // encoding first symbol -- uniform
    IA = part; 
    IAbreakdown.push_back(part);
    char prev = fsastr[0];
    for (size_t i = 1; i < fsastr.length(); i++) {
        char curr = fsastr[i];
        if (i <= mSP || i >= mEP)  continue;
        else {
            if (prev == 'm' && curr == 'm')       { cntrs[0][0]++; cntrs[0][3]++;}
            else  if (prev == 'm' && curr == 'i') { cntrs[0][1]++; cntrs[0][3]++;}
            else  if (prev == 'm' && curr == 'd') { cntrs[0][2]++;  cntrs[0][3]++;}
            else if (prev == 'i' && curr == 'm')  { cntrs[1][0]++;  cntrs[1][3]++;}
            else  if (prev == 'i' && curr == 'i') { cntrs[1][1]++;  cntrs[1][3]++;}
            else  if (prev == 'i' && curr == 'd') { cntrs[1][2]++;  cntrs[1][3]++;}
            else if (prev == 'd' && curr == 'm')  { cntrs[2][0]++;  cntrs[2][3]++;}
            else  if (prev == 'd' && curr == 'i') { cntrs[2][1]++;  cntrs[2][3]++;}
            else  if (prev == 'd' && curr == 'd') { cntrs[2][2]++;  cntrs[2][3]++;}
        }
        prev = curr;
    }
    prev = fsastr[0];
    part = 0;
    for (size_t i = 1; i < fsastr.length(); i++) {
        char curr = fsastr[i];
        if (i <= mSP || i >= mEP) IAbreakdown.push_back(0);
        else {
            if (prev == 'm' && curr == 'm') {
                part = -log(cntrs[0][0]/cntrs[0][3]);
            }
            else  if (prev == 'm' && curr == 'i') {
                part = -log(cntrs[0][1]/cntrs[0][3]);
            }
            else  if (prev == 'm' && curr == 'd') {
                part = -log(cntrs[0][2]/cntrs[0][3]);
            }
            else if (prev == 'i' && curr == 'm') {
                part = -log(cntrs[1][0]/cntrs[1][3]);
            }
            else  if (prev == 'i' && curr == 'i') {
                part = -log(cntrs[1][1]/cntrs[1][3]);
            }
            else  if (prev == 'i' && curr == 'd') {
                part = -log(cntrs[1][2]/cntrs[1][3]);
            }
            else if (prev == 'd' && curr == 'm') {
                part = -log(cntrs[2][0]/cntrs[2][3]);
            }
            else  if (prev == 'd' && curr == 'i') {
                part = -log(cntrs[2][1]/cntrs[2][3]);
            }
            else  if (prev == 'd' && curr == 'd') {
                part = -log(cntrs[2][2]/cntrs[2][3]);
            }
            
            IA += part; 
            IAbreakdown.push_back(part);
        }
        prev = curr;


        
    }
        /*
        //debug
        for(size_t k = 0 ; k < 3; k++) {
            for (size_t l = 0; l < 4; l++) {
                cout << setw(9) << setprecision(3) << fixed << cntrs[k][l];
            }
            cout << endl;
        }
        cout << "probabilities" << endl;
        for(size_t k = 0 ; k < 3; k++) {
            for (size_t l = 0; l < 4; l++) {
                cout << setw(9) << setprecision(3) << fixed << cntrs[k][l]/cntrs[k][3];
            }
            cout << endl;
        }
        */
    part = logStarNew_nits(fsastr.size());
    IA += part; // cost of stating length 
    return IA;
}


double computeIABlockEncoding(string fsastr,vector<double> &IAbreakdown)  {
    
    /*for (size_t i = 0; i < 100; i++) cout << i << " " << logStarNew_bits(i+1) << endl;
    exit(0);*/

    size_t nI_left, nD_left, nI_right, nD_right;
    nI_left = nI_right = nD_left = nD_right = 0;
    size_t mSP = 0, mEP = 0; // start and end point of 'm' state
    //left terminal nIs and nDs
    for (size_t i = 0; i < fsastr.size(); i++) {
        if (fsastr[i] == 'm'){
            mSP = i;
            break;
        }
        else if (fsastr[i] == 'i') nI_left++;
        else if (fsastr[i] == 'd') nD_left++;
    }
    for (ssize_t i = fsastr.size()-1; i >= 0; i--) {
        if (fsastr[i] == 'm') {
            mEP = i;
            break;
        }
        else if (fsastr[i] == 'i') nI_right++;
        else if (fsastr[i] == 'd') nD_right++;
    }
    double IA = 0;
    IA += logStarNew_nits(nI_left+1) ;
    IA += logStarNew_nits(nD_left+1) ;
    IA += logStarNew_nits(nI_right+1) ;
    IA += logStarNew_nits(nD_right+1) ;
    double part = 0;
                          /*         m  i  d sum  */
    double cntrs[3][4] = {/* m */ {  1, 1, 1, 3   },
                          /* i */ {  1, 1, 1, 3   },       
                          /* d */ {  1, 1, 1, 3   } };       
    
    char prev = fsastr[0];
    for (size_t i = 1; i < fsastr.length(); i++) {
        char curr = fsastr[i];
        if (curr == '|') continue;
        if (i <= mSP || i >= mEP)  continue;
        else {
            if (prev == 'm' && curr == 'm')       { cntrs[0][0]++; cntrs[0][3]++;}
            else  if (prev == 'm' && curr == 'i') { cntrs[0][1]++; cntrs[0][3]++;}
            else  if (prev == 'm' && curr == 'd') { cntrs[0][2]++;  cntrs[0][3]++;}
            else if (prev == 'i' && curr == 'm')  { cntrs[1][0]++;  cntrs[1][3]++;}
            else  if (prev == 'i' && curr == 'i') { cntrs[1][1]++;  cntrs[1][3]++;}
            else  if (prev == 'i' && curr == 'd') { cntrs[1][2]++;  cntrs[1][3]++;}
            else if (prev == 'd' && curr == 'm')  { cntrs[2][0]++;  cntrs[2][3]++;}
            else  if (prev == 'd' && curr == 'i') { cntrs[2][1]++;  cntrs[2][3]++;}
            else  if (prev == 'd' && curr == 'd') { cntrs[2][2]++;  cntrs[2][3]++;}
        }
        prev = curr;
    }
    prev = fsastr[0];
    part = 0;

    //enforce symmetry
    // pr m->i = pr m->d
    cntrs[0][1] = (cntrs[0][1]+cntrs[0][2])/2;
    cntrs[0][2] = cntrs[0][1];
    //pr i->m = pr d->m
    cntrs[1][0] = (cntrs[1][0]+cntrs[2][0])/2;
    cntrs[2][0] = cntrs[1][0];
    //pr i->d = pr d->i
    cntrs[1][2] = (cntrs[1][2]+cntrs[2][1])/2;
    cntrs[2][1] = cntrs[1][2];
    //pr i->i = pr d->d
    cntrs[1][1] = (cntrs[1][1]+cntrs[2][2])/2;
    cntrs[2][2] = cntrs[1][1];
    //update counters
    cntrs[0][3] = cntrs[0][0]+cntrs[0][1]+cntrs[0][2];
    cntrs[1][3] = cntrs[1][0]+cntrs[1][1]+cntrs[1][2];
    cntrs[2][3] = cntrs[2][0]+cntrs[2][1]+cntrs[2][2];



    size_t nIs = 0, nDs = 0;
    if (prev == 'm') {
        IA  = logStarNew_nits(nIs+1);
        IA += logStarNew_nits(nDs+1);
        part = 0; 
        IA += part; 
        IAbreakdown.push_back(part);
        nIs = nDs = 0;
    }
    else if (prev == 'i') {
        nIs = 1; nDs = 0;
    }
    else if (prev == 'd') {
        nIs = 0; nDs = 1;
    }
    prev = fsastr[0];
    for (size_t i = 1; i < fsastr.length(); i++) {
        char curr = fsastr[i];
        if (prev == 'm' && curr == 'm') {
            part = -log(cntrs[0][0]/cntrs[0][3]);
            IA += part;
            IAbreakdown.push_back(part); // first m
        }
        else  if (prev == 'm' && curr == 'i') {
            nIs++;
        }
        else  if (prev == 'm' && curr == 'd') {
            nDs++;
        }
        else if (prev == 'i' && curr == 'm') {
            part  = logStarNew_nits(nIs+1);
            part += logStarNew_nits(nDs+1);
            for (size_t j = 0; j < nIs+nDs; j++) 
                IAbreakdown.push_back(part/(nIs+nDs)); 
            IAbreakdown.push_back(0); // first m
            IA += part;
            nIs = nDs = 0;
        }
        else  if (prev == 'i' && curr == 'i') {
            nIs++;
        }
        else  if (prev == 'i' && curr == 'd') {
            nDs++;
        }
        else if (prev == 'd' && curr == 'm') {
            part  = logStarNew_nits(nIs+1);
            part += logStarNew_nits(nDs+1);
            for (size_t j = 0; j < nIs+nDs; j++) 
                IAbreakdown.push_back(part/(nIs+nDs)); 
            IAbreakdown.push_back(0); // first m
            IA += part;
            nIs = nDs = 0;
        }
        else  if (prev == 'd' && curr == 'i') {
            nIs++;
        }
        else  if (prev == 'd' && curr == 'd') {
            nDs++;
        }
        prev = curr;
    }
    //terminal gap right
    part  = logStarNew_nits(nIs+1);
    part += logStarNew_nits(nDs+1);
    for (size_t j = 0; j < nIs+nDs; j++) 
        IAbreakdown.push_back(part/(nIs+nDs)); 
    IA += part;
    //cout<< nIs << " " << nDs<< " " << fsastr << " "<< IAbreakdown.size() <<  " " << fsastr.length() << endl;
    assert (IAbreakdown.size() == fsastr.length());
    return IA;
}

double negLogProbChiDist(double x, double sigma, double eps) {
    //cout << "chi: x = " << x << " " << "sigma = " << sigma << endl;
    // f(x;sigma) = x^2/sigma^3 . 1/sqrt(pi/2) . exp(-x^2/2sigma^2)
    double msglen = 0;
    msglen = -2*log(x) + 3*log(sigma) 
        + log(M_PI/2)/2 + x*x/(2*sigma*sigma) - log(eps);
    //cout << "chi msglen = " << nits2bits(msglen) << endl;;
    return msglen;
}


double getPositionalEncoding(
 vector<double> S_im1,
 vector<double> S_i,
 vector<double> T_jm1,
 vector<double> T_j,
 double rmsd) {
    if (rmsd < 0.1) rmsd = 0.1;
    double Sim1[3], Si[3], Tjm1[3],Tj[3];
    if (S_im1.size() ==3) dv2da(S_im1,Sim1);
    dv2da(S_i,Si);
    dv2da(T_jm1,Tjm1);
    dv2da(T_j,Tj);

    //compute radius of first sphere centered at S_i
    double vecSiToTj[3]; // error vec 
    computeVectorDifference(Tj,Si, vecSiToTj);
    double r = vectorNorm(vecSiToTj);
    if (VERBOSE2) cout << endl << "(rmsd, chi-sigma) = " << rmsd << ", " << rmsd/sqrt(3) << endl;
    if (VERBOSE2) cout << "sphere (Si to Tj)   radius (r) = " << setprecision(2) << r<< " ";

    //compute radius of second sphere centered at T_j-i
    double vecTjm1ToTj[3]; // chain vec
    computeVectorDifference(Tj,Tjm1,vecTjm1ToTj);
    double R = vectorNorm(vecTjm1ToTj);
    //cout << "sphere2_radius = " << R << endl;
    double msglen = 0;

    //compute the angle between vectors vecTjm1ToTj and vecSiToTj
    double theta_dr = computeAngle(vecTjm1ToTj,vecSiToTj);
    if (r < 0.1) theta_dr = 0;
    if (theta_dr >= M_PI/4 && theta_dr < M_PI/2) theta_dr -= (M_PI/4); 
    else if (theta_dr >= M_PI/2 && theta_dr < 3*M_PI/4) theta_dr -= (M_PI/2); 
    else if (theta_dr >= 3*M_PI/4 && theta_dr <= M_PI) theta_dr -= (3*M_PI/4); 

    double eps_dr = AOM*cos(theta_dr);
    if (VERBOSE2) cout << "angle = " << setprecision(2) << theta_dr*180/M_PI << " ";
    if (VERBOSE2) cout << "dr = " << setprecision(5) << eps_dr << " ";
    
    
    //encode sphere1_radius over a chi distribution
    double sigma = rmsd/sqrt(3);
    /*
    if (r/sigma < sqrt(2)) {
        r = sigma*sqrt(2);
        //cout << "\t reset_sphere radius = " << r << endl;
    }
    */
    //msglen  = negLogProbChiDist(r,sigma,AOM);
    if (r < 0.1) r = 0.1;
    msglen  = negLogProbChiDist(r,sigma,eps_dr);
    if (VERBOSE2) cout << setw(4) << setprecision(1)  << "I(r) = "<< nits2bits(msglen) << endl;


    //double tmp[3];
    //tmp[0] = vecSiToTj[0]; tmp[1] = vecSiToTj[1]; tmp[2] = vecSiToTj[2];


    //encode sphere2_radius over a normal distribution
    if (VERBOSE2) cout << "sphere (Tjm1 to Tj) radius (R) = " << setprecision(2) << R << " ";
    msglen += negLogProbNormalDist(R,3.8,0.4,AOM);
    if (VERBOSE2) cout  << setw(3) << setprecision(2) << "I(R) = " << nits2bits(negLogProbNormalDist(R,3.8,0.4,AOM)) << endl;

    //compute radius of the circle which is the intersection of two spheres
    double vecTjm1ToSi[3]; //center vec
    computeVectorDifference(Si,Tjm1,vecTjm1ToSi);
    double d = vectorNorm(vecTjm1ToSi);
    //cout << "Si to Tjm1 centers distance " << d << endl;
    double dsq = d*d;
    double Rsq = R*R;
    double rsq = r*r;
    double c = sqrt(4*dsq*Rsq-(dsq-rsq+Rsq)*(dsq-rsq+Rsq))/(2*d);
    if (VERBOSE2) cout << "Circle radius (c) = " << setprecision(2) << c << " ";
    if (c < 0.3) {
        c = 0.3;
        if (VERBOSE2) cout << "(reset" << c << ") "; 
    }
    msglen += (-log(AOM/(M_PI*c))-1); // encode uniformly on the semi-circle of intersection
    if (VERBOSE2) cout  << "I(Tj-on-circle) = "<< setw(4) << setprecision(1) << nits2bits(-log(AOM/(2*M_PI*c))) << endl;
    return msglen;
}

double statementCostRMSD(double n __attribute__((unused))) {
    return bits2nits((double)7.00932); 
}

vector<double> computeIvalue(  
 string fsastr,
 vector<vector<double> > Sorig,  //full coordinates of structure S 
 vector<vector<double> > Torig,  //full coordinates of structure T
 bool printIvalueSummaryFlag
 ) {
    fsastr = canonicalizefsa(fsastr);
    vector<vector<double> > S = Sorig;
    vector<vector<double> > T = Torig;

    KentMixtureModel kent;
    CACoordinateEncoding_t S_encobj(S,kent);
    CACoordinateEncoding_t T_encobj(T,kent);

    double rIA=0, rIS=0, rIT = 0, rITgSA=0;
    //double IS = S_encobj.getIThetaPhiRadius();
    //double IT = T_encobj.getIThetaPhiRadius();

    vector<double> IAbreakdown;
    double IA = computeIAnewSymmetric(fsastr,IAbreakdown);

    double rmsd = superposeTonSUsingAlignment(fsastr,S,T);
    double sigma = rmsd;
    //prior on sigma parameter used in chi-distribution 
    size_t nMs = getnMatches(fsastr);
    double covS = (float)nMs/(float)S.size();
    double covT = (float)nMs/(float)T.size();
    if (sigma  < 0.5 && (covS > 0.99 || covT > 0.99)) {
        sigma = 0.5;
    }
    else if (sigma < 1.5)    sigma = 1.5;
    else if(sigma >4) sigma = 4;

    size_t scntr = 0, tcntr = 0, nMatches = 0, nMatchesInBlock = 0;
    double pIA, pIS, pIT, pITgSA;
    vector<double> empty;
    for (size_t i = 0; i < fsastr.length(); i++) {
        pIA = pIT = pIS = pITgSA = 0;
        pIA = IAbreakdown[i];
        if (fsastr[i] == 'i') {
            pITgSA = T_encobj.getIThetaPhiRadius(tcntr++);
            pIT = pITgSA;
            nMatchesInBlock = 0;
        }
        else if (fsastr[i] == 'd') {
            pIS = S_encobj.getIThetaPhiRadius(scntr++);
            nMatchesInBlock = 0;
        }
        else if (fsastr[i] == 'm') {
            pIT = T_encobj.getIThetaPhiRadius(tcntr);
            //if (scntr==0 && tcntr == 0) nothing necessary to be done
            if (scntr > 0 && tcntr == 0) {
                pIS = S_encobj.getIThetaPhiRadius(scntr);
            }
            else if (scntr == 0 && tcntr > 0) {
                double IPositional = getPositionalEncoding(empty,S[scntr],T[tcntr-1],T[tcntr],sigma);
                double prPositional = exp(-IPositional);
                double prNull = exp(-pIT);
                pITgSA = -log((prPositional+prNull)/2);
            }
            else if (scntr > 0 && tcntr > 0) {
                pIS = S_encobj.getIThetaPhiRadius(scntr);
                if (nMatchesInBlock < 3) {
                    ///*
                    if (nMatchesInBlock == 0) {
                        double IPositional = getPositionalEncoding(empty,S[scntr],T[tcntr-1],T[tcntr],sigma);
                        double prPositional = exp(-IPositional);  
                        double prNull = exp(-pIT);
                        pITgSA = -log((prPositional+prNull)/2);
                        //if (pIT - pITgSA > bits2nits(4)) pITgSA = pIT-bits2nits(4);

                    }
                    else {
                        double IPositional = getPositionalEncoding(S[scntr-1],S[scntr],T[tcntr-1],T[tcntr],sigma);
                        double prPositional = exp(-IPositional);  
                        double prNull = exp(-pIT);
                        pITgSA = -log((prPositional+prNull)/2);
                        //if (pIT - pITgSA > bits2nits(4)) pITgSA = pIT-bits2nits(4);
                    }//*/
                    //pITgSA = pIT;
                }
                else {
                    double IPositional =  
                        getPositionalEncoding(S[scntr-1],S[scntr],T[tcntr-1], T[tcntr],sigma);
                    vector<double> likelihoods = 
                        S_encobj.getComponentLikelihoods(scntr);
                    double IDirectional = T_encobj.getReweightedIThetaPhiRadius(tcntr, likelihoods,kent);
                    double prPositional  = exp(-IPositional);
                    double prDirectional = exp(-IDirectional);
                    //double prNull = exp(-pIT);
                    if (VERBOSE2) cout << "IT_pos =" << nits2bits(IPositional) << "\t\t";
                    if (VERBOSE2) cout << "IT_dir =" << nits2bits(IDirectional) << endl;

                    pITgSA = -log(0.5*prPositional+0.5*prDirectional);
                    //if (pIT - pITgSA > bits2nits(4)) pITgSA = pIT-bits2nits(4);
                    //pITgSA *= 0.95;
                }
            }
            scntr++;
            tcntr++;
            nMatches++;
            nMatchesInBlock++;
        }
        else if (fsastr[i] == '|') {
            nMatchesInBlock = 0;
        }
        rIA += pIA;
        rIS += pIS;
        rIT += pIT;
        rITgSA += pITgSA;
        if (VERBOSE) {
            if (i == 0 ) 
                cout << "0 ---> " << fsastr[i] << " ";
            else 
                cout << fsastr[i-1] << " ---> " << fsastr[i] << " ";
             
            cout << " IA=" << setw(5) << setprecision(1) << fixed << nits2bits(pIA)
                 << " IS=" << setw(6) << setprecision(3) << fixed << nits2bits(pIS)
                 << " IT=" << setw(6) << setprecision(1) << fixed << nits2bits(pIT)
                 << " ITgSA=" << setw(6) << setprecision(1) << fixed << nits2bits(pITgSA) 
                 << " IT-ITgSA= " << setw(6) << setprecision(1) << fixed << nits2bits(pIT-pITgSA) << endl;
        }
    }
    assert(scntr==S.size() && tcntr==T.size());
    rIA = IA; //forced due to symmetric IA computation 
    //assert(fabs(rIS - IS) < 0.000001);
    double NULLS = S_encobj.getNullModelMessageLength(); 
    double NULLT = T_encobj.getNullModelMessageLength();
    double NULLST = NULLS+NULLT;
    double IAST = rIA+rIS+rITgSA;
    IAST += statementCostRMSD(nMatches);
    double diff = NULLST-IAST;

    if (printIvalueSummaryFlag) {
        cout << "Structure Sizes =   " << S.size() << ", " 
             << T.size() << endl ;
        cout << "Coverage        =   " << left  << setw(9) << nMatches << endl;
        cout << "RMSD            = " << right << setw(9) << rmsd  << " A" << endl;
        cout << "I(A)            = " << right << setw(9) << nits2bits(IA) << " bits" << endl;
        //cout << "NULL(S)         = " << right << setw(9) << nits2bits(NULLS) << " bits" << endl;
        //cout << "NULL(T)         = " << right << setw(9) << nits2bits(NULLT) << " bits" << endl;
        //cout << "I(TgSA)         = " << right << setw(9) << nits2bits(rITgSA) << " bits" << endl;
        //cout << "NULL(T)-I(TgSA) = " << right << setw(9) << nits2bits(NULLT)-nits2bits(rITgSA) << " bits" << endl;
        cout << "NULL(S & T)     = " << right << setw(9) << nits2bits(NULLST) << " bits" << endl;
        cout << "I(A & <S,T>)    = " << right << setw(9) << nits2bits(IAST) << " bits" << endl;

        cout << "Compression     = " << right << setw(9) << nits2bits(diff) << " bits (+ve better; -ve worse)" << endl;
    }
    
    vector<double> algnstats;
    algnstats.push_back(IAST);    //[0]  IValue
    algnstats.push_back(NULLS);   //[1]  Null of S
    algnstats.push_back(NULLT);   //[2]  Null of T
    algnstats.push_back(IA);      //[3]  IA
    algnstats.push_back(rITgSA);  //[4]  rITgSA
    algnstats.push_back(diff);    //[5]  compression
    algnstats.push_back(NULLST);  //[6]  Null of S & T
    algnstats.push_back(nMatches);//[7]  nMatches
    algnstats.push_back(rmsd);    //[8]  rmsd 
    algnstats.push_back(S.size());//[9]  S.size()
    algnstats.push_back(T.size());//[10] T.size()
    return algnstats;
}


