/* Some useful functions
 * Copyright (C) 2017 Laboratory of Computational Biology, Monash University
 * (http://lcb.infotech.monash.edu.au)
 *
 * Reference:
 *   J. H. Collier, L. Allison, A. M. Lesk, P.J. Stuckey,
 *   M. Garcia de la Banda, A. S. Konagurthu.
 *   Bioinformatics 33(7):1005-1013, 2017.
 *
 * MMLigner is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MMLigner is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MMLigner. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef MISC_H
#define MISC_H
#include<iostream>
#include<fstream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cassert>
#include<string>
#include<stdint.h>
#include<map>
#include<vector>
#include<sstream>
#include<time.h>
#include<math.h>
#include "superpose3D.h"


/* defined indexes into the alignstats vector produced by computeIvalue
 */
enum {
  ALIGNSTATS_IDX_IVALUE = 0,
  ALIGNSTATS_IDX_NULLS,
  ALIGNSTATS_IDX_NULLT,
  ALIGNSTATS_IDX_IA,
  ALIGNSTATS_IDX_ITSA,
  ALIGNSTATS_IDX_COMPRESSION,
  ALIGNSTATS_IDX_NULLST,
  ALIGNSTATS_IDX_NMATCH,
  ALIGNSTATS_IDX_RMSD,
  ALIGNSTATS_IDX_NS,
  ALIGNSTATS_IDX_NT,
};


using namespace std;
vector<double> doubleArray2VectorOfDouble(double [], size_t);
float SSMScore(size_t, size_t, size_t, float);
float TopofitScore(size_t, float);
float combinatorialSSMScore(size_t, size_t, size_t, float, size_t);
float combinatorialTopofitScore(size_t, float, size_t);
float adHocScore(size_t,  float);
size_t choose(size_t,size_t);
size_t choose2(size_t);
size_t choose3(size_t);

string canonicalizefsa(string&);
size_t getnMatches(string);
size_t getnRigidBlocks(string);
size_t getnMatchBlocks(string);
size_t getnHinges(string);
vector<int> getHingePositions(string);
double getRMSD(string,vector<vector<double> >, vector<vector<double> >);
double superposeTonSUsingAlignment(string,vector<vector<double> >&,vector<vector<double> >&);
bool sanityCheckAlignment(string,vector<vector<double> >,vector<vector<double> >);
void da2dv(double arr[3], vector<double> &vec);
void dv2da(vector<double> &vec, double arr[3]);
string getFilenameFromPath(const char *str);
double nits2bits(double x);
double bits2nits(double x);
void writeAlignmentStatsToFile(vector<double> &, string, bool);
void printToTerminalMsg(ostringstream &);
void printToTerminalMsgStatus(string);
void printToTerminalMsgStatus_wo_newline(string);
string getTerminalColorString(string,size_t);
void printPercentCompleted(size_t,size_t,size_t,size_t);


#endif
