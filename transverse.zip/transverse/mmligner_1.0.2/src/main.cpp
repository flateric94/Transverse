/* Main
 * Copyright (C) 2017 Laboratory of Computational Biology, Monash University
 * (http://lcb.infotech.monash.edu.au)
 *
 * Reference:
 *   J. H. Collier, L. Allison, A. M. Lesk, P.J. Stuckey,
 *   M. Garcia de la Banda, A. S. Konagurthu.
 *   Bioinformatics 33(7):1005-1013, 2017.
 *
 * MMLigner is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MMLigner is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MMLigner. If not, see <http://www.gnu.org/licenses/>.
 */

#include<iostream>
#include<fstream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cassert>
#include<string>
#include<stdint.h>
#include<map>
#include<vector>
#include<sstream>
#include<algorithm>
#include <ctime>

#include "mmligner_config.h"
#include "cmdLineParser.h"
#include "fastautils.h"
#include "pdbClass.h"
#include "MFPClass.h"
#include "AlignClass.h"
#include "structureInformationClass.h"
#include "misc.h"
#include "em.h"
#include "ivalue.h"
#include "seedAlignmentUtils.h"

using namespace std;

void coutHeader() {
  cout << "\033[0;37;1;44m";
  cout << setw(78) 
        << "MMLigner (v" MMLIGNER_VERSION "): Minimum Message Length (MML) alignment of protein structures "
       << "\033[0;0m\n";
       //<< "\033[0;37;1;44m";
  //<< setw(78) <<  "    " << "\033[0;0m   \n" ;
  cout << "\033[0;1;37;1;46m" ;
  cout << "   Authors:" ; 
  cout << "\033[0;1;37;1;46m" ;
  cout << "    Collier, Allison, Lesk, Stuckey, Garcia de la Banda, Konagurthu. \033[0m\n";
  cout << "\033[1;37;1;46m";
  cout << "   Reference:" ; 
  cout << "\033[0;1;37;1;46m" ;
  cout << "  Bioinformatics. 33(7):1005-1013, 2017.                           \033[0m\n";
  cout << left << setw(82);
  cout << endl;
}


void writeSuperposedPDBfile(
  structureInformationClass &struct_S,      
  structureInformationClass &struct_T,
  string fsastr,
  string outfname,
  bool flag
) {
  vector<vector<double> > S = struct_S.coords;
  vector<vector<double> > T = struct_T.coords;
  PDB_t pdb_S = struct_S.pdbobj;
  PDB_t pdb_T = struct_T.pdbobj;

  vector<vector<double> > mS; //collects matches in S
  vector<vector<double> > mT; //collects matches in T
  size_t scntr = 0;
  size_t tcntr = 0;
  size_t nMatches = 0 ;
  for (size_t i = 0; i < fsastr.length(); i++) {
    if(fsastr[i] == 'm') {
      mS.push_back(S[scntr]);
      mT.push_back(T[tcntr]);
      scntr++;
      tcntr++;
      nMatches++;
    }
    else if(fsastr[i] == 'i') {
      tcntr++;
    }
    else if (fsastr[i] == '|') continue;
    else {
      scntr++;
    }
  }
  assert(scntr==S.size());
  assert(tcntr==T.size());
  if (nMatches < 3) return;
  //else
  if (!flag) {
      Superpose3DClass obj(mT,mS);
      pdb_T.printPDB(outfname.c_str(),obj);
  }
  else {
      Superpose3DClass obj(mS,mT);
      pdb_S.printPDB(outfname.c_str(),obj);
  }
}

void sortAlignmentsOnCompression(
 vector<string> &fsastrings,
 vector<double> &compression){
   if (fsastrings.size() < 2) return;

   for (size_t i = 1; i < fsastrings.size(); i++) {
      double key_i = compression[i];
      string key_i_str = fsastrings[i];
      ssize_t j = i-1;
      while(j >=0 && compression[j] <  key_i) {
         compression[j+1] = compression[j];
         fsastrings[j+1]  = fsastrings[j];
         j--;
      }
      compression[j+1] =  key_i;
      fsastrings[j+1]  =  key_i_str;
   }
}





int main( int argc , char *argv[] ) {
  coutHeader();

  ostringstream oss;
  vector<string> param_structFileNames;
  vector<string> param_structChainIDs;
  bool param_ivalue = false;
  string param_fasta_fname;
  bool param_superposed_pdb = false;
  string param_output_prefix_string;

  parseCmdLine(argc,argv,
          param_structFileNames,param_structChainIDs,
          param_ivalue,param_fasta_fname,param_superposed_pdb,
          param_output_prefix_string);
 
  structureInformationClass struct_S;
  structureInformationClass struct_T;
  bool kramaflag = readStructures(param_structFileNames,param_structChainIDs,struct_S,struct_T);

  if (false) {
      cout << "Sizes: "<< struct_S.size << " " << struct_T.size << endl;
      cout << "param_ivalue: " << param_ivalue << endl;
      cout << "param_fasta_fname: " << param_fasta_fname << endl;
      cout << "param_superposed_pdb: " << param_superposed_pdb << endl;
      cout << "param_output_prefix_string: " << param_output_prefix_string << endl;
      cout << "param_structFileNames: " << param_structFileNames[0] 
                                        << " " 
                                        << param_structFileNames[1] << endl;
      cout << "param_structChainIDs: "  << param_structChainIDs[0] 
                                        << " " 
                                        << param_structChainIDs[1] << endl;
      cout << "krama?: " << kramaflag << endl;
  }

  if (param_ivalue) { // if running an ivalue computation
     size_t offset = param_fasta_fname.size()>32?32:param_fasta_fname.size();
     oss << "Computing Ivalue of         ..."
         << param_fasta_fname.substr(param_fasta_fname.size()-offset) << flush;
     printToTerminalMsg(oss);
     cerr << setw(4) << " ";
     string fsastr = fastaAlignment2fsa(param_fasta_fname.c_str());
     vector<double> algnstats 
         = computeIvalue(fsastr,struct_S.coords,struct_T.coords,false);
     string outfname = param_output_prefix_string + ".stats";
     writeAlignmentStatsToFile(algnstats,outfname,kramaflag);
     printToTerminalMsgStatus("OK");
     oss.str("");
     oss.clear();
     oss << "       Alignment Stats written to: ..." << outfname << endl;
     printToTerminalMsg(oss);
     cout << "Alignment stats\n";
     algnstats = computeIvalue(fsastr,struct_S.coords,struct_T.coords,true);
     cout << setw(43) << right << "--=o0o=--"<< endl 
          << setw(53) << right << getTerminalColorString("DONE",35) << endl
          << setw(43) << right << "--=o0o=--"<< endl ;
     return 0;
  }
  //else if running mmligner computation
  cout << "Computing MMLigner alignment..." << endl;
  vector<string> seedAlignmentFSAstrings = generateSeedAlignments(struct_S,struct_T);  

  cout << "...expectation maximization on seed alignments using I-value..." << endl;
  vector<string> algn_fsastrings;
  vector<double> algn_compression;
  size_t nPerturbed = 0;
  for (size_t c = 0; c < seedAlignmentFSAstrings.size(); c++) {
      oss.str("");
      oss.clear();
      oss << "   ...perturbing seed alignment " << c+1 << " of " << seedAlignmentFSAstrings.size();
      printToTerminalMsg(oss);
      double compression=-1;
      string clust_optfsa = expectationMaximization(seedAlignmentFSAstrings[c],
                                            struct_S.coords,struct_T.coords,
                                            compression);
      bool uniqflag = true;
      for (size_t j = 0; j < algn_fsastrings.size(); j++) {
          if (algn_fsastrings[j].compare(clust_optfsa) == 0) {
              uniqflag = false; 
              break;
          }
      }
      if (compression > 0 && uniqflag == true) {
        algn_fsastrings.push_back(clust_optfsa);
        algn_compression.push_back(compression);
      }
      cout << setw(6) << " ";
      printToTerminalMsgStatus("OK");
      nPerturbed++;
      if (nPerturbed >=10) break;
  }
  assert(algn_compression.size() == algn_fsastrings.size());
  if (algn_fsastrings.size() == 0) {
        string fsastr = getUnalignedFSAString(struct_S.size,struct_T.size);
        algn_fsastrings.push_back(fsastr);
        cout << "   [none of the resultant alignments are significant]\n";
  }
  else if (algn_compression.size() == 1) {
      cout << "   [only 1 resultant alignment is significant]\n";
  }
  else if (algn_compression.size() < seedAlignmentFSAstrings.size()) {
      cout << "   [only " << algn_compression.size() << " resultant alignments are significant]\n";
  }
  //sorting algn_fsastrings on compression
  sortAlignmentsOnCompression(algn_fsastrings,algn_compression);
  for (size_t c = 0; c < algn_fsastrings.size(); c++) {
    oss.str("");
    oss.clear();
    oss << "Writing aligment output to " ;
    vector<string> algn = 
        fsastr2SeqAlignment(algn_fsastrings[c],struct_S.aaseq,struct_T.aaseq);
    assert(algn[0].size()==algn[1].size());
    assert(algn[0].size()==algn_fsastrings[c].size());
    ostringstream ossfname;
    ossfname <<  param_output_prefix_string << "__" << c+1 << ".afasta";
    string outfname = ossfname.str();
    oss << getTerminalColorString(outfname,33);
    printToTerminalMsg(oss);
    writeToFastaFile(algn, outfname,param_structFileNames, kramaflag);
    printToTerminalMsgStatus("OK");

    oss.str("");
    oss.clear();
    oss << "Writing alignment stats to " ;

     vector<double> algnstats 
         = computeIvalue(algn_fsastrings[c],struct_S.coords,struct_T.coords,false);
    ossfname.str("");
    ossfname.clear();
    ossfname <<  param_output_prefix_string << "__" << c+1 << ".stats";
    outfname = ossfname.str();
    oss << getTerminalColorString(outfname,33);
    printToTerminalMsg(oss);
    writeAlignmentStatsToFile(algnstats,outfname,kramaflag);
    cout << " ";
    printToTerminalMsgStatus("OK");

    if (param_superposed_pdb) {
        oss.str("");
        oss.clear();
        oss << "Writing superposed pdb to  " ;
        ossfname.str("");
        ossfname.clear();
        size_t found = param_output_prefix_string.find("_vs_");
        ossfname <<  param_output_prefix_string.substr(found+4) 
                 << "_superposed"
                 << "__" << c+1 << ".pdb";
        outfname = ossfname.str();
        oss << getTerminalColorString(outfname,33);
        printToTerminalMsg(oss);
        writeSuperposedPDBfile(struct_S,struct_T,algn_fsastrings[c],outfname,kramaflag);
        cout << setw(6) << " ";
        printToTerminalMsgStatus("OK");
    }
  }
  cout << "Summary:\n";
  for (size_t c = 0; c < algn_fsastrings.size(); c++) {
     cout << "Alignment " << c+1 << " stats\n";
     vector<double> tmp 
         = computeIvalue(algn_fsastrings[c],struct_S.coords,struct_T.coords,true);
     cout << "-------\n";
  }
   cout << "[ \033[32;4m ALL DONE!!!\033[0m ]\n" ;
   cout << "\033[36;4m.                                    -=o0o=-                                   .\033[0m\n" ;
   cout << "\033[36;3m|                                   REFERENCE                                  |\033[0m\n" ;
   cout << "\033[33;3m"
        << "| J.Collier, L.Allison, A.Lesk, P.Stuckey, M.Garcia de la Banda, A.Konagurthu  |\n" 
        << "| Statistical inference of protein structural alignments using information and |\n" 
        << "| compression, Bioinformatics. 33(7):1005-1013, 2017.                          |\033[0m\n";
   cout << "\033[35;3m| DOI: https://doi.org/10.1093/bioinformatics/btw757                           |\033[0m\n" ;
   cout << "\033[36;4m|                                    -=o0o=-                                   |\033[0m\n" ;
   cout << "\033[37;2m| See other LCB structural bioinformatics tools:                               |\033[0m\n" ;
   cout << "\033[37;2m|  * MUSTANG: http://lcb.infotech.monash.edu.au/mustang                        |\033[0m\n" ;
   cout << "\033[37;2m|  * SST    : http://lcb.infotech.monash.edu.au/sstweb                         |\033[0m\n" ;
   cout << "\033[37;2m|  * SUPER  : http://lcb.infotech.monash.edu.au/super                          |\033[0m\n" ;
   cout << "\033[37;2m|-------------------------------------0o.o0------------------------------------|\033[0m\n" ;

  return 0;
}

