/* Dynammic programming for seed alignments
 * Copyright (C) 2017 Laboratory of Computational Biology, Monash University
 * (http://lcb.infotech.monash.edu.au)
 *
 * Reference:
 *   J. H. Collier, L. Allison, A. M. Lesk, P.J. Stuckey,
 *   M. Garcia de la Banda, A. S. Konagurthu.
 *   Bioinformatics 33(7):1005-1013, 2017.
 *
 * MMLigner is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MMLigner is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MMLigner. If not, see <http://www.gnu.org/licenses/>.
 */

#include "dp.h"
#include "em.h"


string alignClosestAfterSuperposition(  
 string fsastr,
 vector<vector<double> > S, //full coordinates of structure S 
 vector<vector<double> > T, //full coordinates of structure T
 double distanceThreshold 
) {
  float go = 0 , ge = 0 ;
  float NEGINFTY = -9999999;
  double Si[3], Tj[3];

  if (distanceThreshold >= 0) superposeTonSUsingAlignment(fsastr,S,T);
  //else when distanceThreshold == -1, this is aligning a matched block with S,T prev superposed

  //alloc memory for distmat, scoremat
  size_t dim1 = S.size();
  size_t dim2 = T.size();
  vector<vector<float> > distmat,scoremat;
  for (size_t i = 0; i < dim1; i++) {
     vector<float> tmp(dim2);
     distmat.push_back(tmp);
     scoremat.push_back(tmp);
  }
  
    //compute pairwise distance matrix
  double maxdist = 0;
  for (size_t i = 0; i < S.size(); i++) {
      dv2da(S[i],Si);
      for (size_t j = 0; j < T.size(); j++) {
          dv2da(T[j],Tj);
          distmat[i][j] = normAminusB(Si,Tj);
          if (distmat[i][j] > maxdist) maxdist = distmat[i][j];
      }
  }
  if (distanceThreshold < 0) { // this signals the use of max distance as the threshold
      //find the max distance among currently matched pairs;
      double max_m_dist = 0;
      double dist_sum=0, dist_sumsq=0;
      size_t dist_n =0;
      ssize_t scntr = -1, tcntr = -1;
      for (size_t i = 0; i < fsastr.length(); i++) {
          if (fsastr[i] == 'm') {
              scntr++; 
              tcntr++;
              double Si[3];
              double Tj[3];
              dv2da(S[scntr],Si);
              dv2da(T[tcntr],Tj);
              double dist = normAminusB(Si,Tj);
              if (dist > max_m_dist) max_m_dist = dist;
              if(max_m_dist < 2) max_m_dist = 2;
              dist_sum += dist;
              dist_sumsq += dist*dist;
              dist_n++;
          }
          else if (fsastr[i] == 'd') {
              scntr++; 
          }
          else if (fsastr[i] == 'i') {
              tcntr++;
          }
      }
      double dist_mu = dist_sum/(double)dist_n;
      double dist_sd = sqrt(dist_sumsq/(double)dist_n - (dist_mu*dist_mu));
      max_m_dist = dist_mu + dist_sd;
      distanceThreshold = max_m_dist;
  }
  //change distance matrix to similarity matrix
  for (size_t i = 0; i < S.size(); i++) {
      for (size_t j = 0; j < T.size(); j++) {
          if (distmat[i][j] < distanceThreshold )
            scoremat[i][j] = maxdist - distmat[i][j];
          else 
            scoremat[i][j] = NEGINFTY;
      }
  }

  vector<vector<float> > smoothenedscoremat = scoremat;
  for (size_t i = 0; i < S.size(); i++) {
      for (size_t j = 0; j < T.size(); j++) {
          double score = scoremat[i][j];
          if (i>0 && j>0) score += scoremat[i-1][j-1];
          if (i<S.size()-1&&j<T.size()-1) score += scoremat[i+1][j+1];
          smoothenedscoremat[i][j] = score/3;
      }

  }
  //scoremat = smoothenedscoremat;



  vector<vector<float> > M,I,D;
  vector<vector<size_t> > Mptr,Iptr,Dptr;

  dim1 = scoremat.size()+1;
  dim2 = scoremat[0].size()+1;
  for (size_t i = 0 ; i < dim1; i++) {
      vector<float> t1(dim2);
      vector<size_t> t2(dim2);
      M.push_back(t1);
      I.push_back(t1);
      D.push_back(t1);
      Mptr.push_back(t2);
      Iptr.push_back(t2);
      Dptr.push_back(t2);
  }

  float arr[3];
/* Derivation codes:
   For matrix M
   0 indicates derives from M
   1 indicates derives from I
   2 indicates derives from D
   For matrix D
   3 indicates derives from M
   4 indicates derives from I
   5 indicates derives from D
   For matrix I
   6 indicates derives from M
   7 indicates derives from I
   8 indicates derives from D

   - indicates impossible derivation!
*/
    M[0][0] = I[0][0] = D[0][0] = Mptr[0][0] = Iptr[0][0] = Dptr[0][0] = 0;

    //boundary row/col of M,I,D
    for (size_t i = 1 ; i < dim1; i++) {
      M[i][0] = D[i][0] = NEGINFTY;
      Mptr[i][0] = Dptr[i][0] = 9 ;
      I[i][0] = go+(i-1)*ge;
      Iptr[i][0] = 4;
    }

    for (size_t j = 1 ; j < dim2; j++) {
      M[0][j] = I[0][j] = NEGINFTY;
      Mptr[0][j] = Iptr[0][j] = 9 ;
      D[0][j] = go+(j-1)*ge;
      Dptr[0][j] = 8;
      arr[1] = I[0][j] ;
      arr[2] = D[0][j] ;
    }

    //rest
    for (size_t i = 1; i < dim1; i++) {
      for (size_t j = 1 ; j <  dim2 ; j++) {
        double specialscore = scoremat[i-1][j-1];
        ///*
        if (i >2 && j>2) {
            specialscore += scoremat[i-2][j-2];
            specialscore /= 2;
        }
        if (i >3 && j>3 && Mptr[i-2][j-2]==0) {
            specialscore *=2;
            specialscore += scoremat[i-3][j-3];
            specialscore /= 3;
        }//*/
        //fill M[i][j]
        arr[0] = M[i-1][j-1] + (float)specialscore ;
        arr[1] = I[i-1][j-1] + (float)scoremat[i-1][j-1] ;
        arr[2] = D[i-1][j-1] + (float)scoremat[i-1][j-1] ;

        //find max
        if (arr[0] >= arr[1] && arr[0] >= arr[2]) {
          M[i][j] = arr[0] ;
          Mptr[i][j] = 0 ;
        }
        else if (arr[1] >= arr[0] && arr[1] >= arr[2]) {
          M[i][j] = arr[1] ;
          Mptr[i][j] = 1 ;
        }
        else if (arr[2] >= arr[0] && arr[2] >= arr[1]) {
          M[i][j] = arr[2] ;
          Mptr[i][j] = 2 ;
        }

        //fill I[i][j]
        arr[0] = M[i-1][j] + go ;
        arr[1] = I[i-1][j] + ge ;
        arr[2] = D[i-1][j] + go ;

        //find max
        if (arr[0] >= arr[1] && arr[0] >= arr[2]) {
          I[i][j] = arr[0] ;
          Iptr[i][j] = 3 ;
        }
        else if (arr[1] >= arr[0] && arr[1] >= arr[2]) {
          I[i][j] = arr[1] ;
          Iptr[i][j] = 4 ;
        }
        else if (arr[2] >= arr[0] && arr[2] >= arr[1]) {
          I[i][j] = arr[2] ;
          Iptr[i][j] = 5 ;
        }

        //fill D[i][j]
        arr[0] = M[i][j-1] + go ;
        arr[1] = I[i][j-1] + go ;
        arr[2] = D[i][j-1] + ge ;

        //find max
        if (arr[0] >= arr[1] && arr[0] >= arr[2]) {
          D[i][j] = arr[0] ;
          Dptr[i][j] = 6 ;
        }
        else if (arr[1] >= arr[0] && arr[1] >= arr[2]) {
          D[i][j] = arr[1] ;
          Dptr[i][j] = 7 ;
        }
        else if (arr[2] >= arr[0] && arr[2] >= arr[1]) {
          D[i][j] = arr[2] ;
          Dptr[i][j] = 8 ;
        }

      }
    }

    float optptr = 9; // 0 points to M, 1 points to I, 2 points to D 
    arr[0] = M[dim1-1][dim2-1] ;
    arr[1] = I[dim1-1][dim2-1] ;
    arr[2] = D[dim1-1][dim2-1] ;
    //find max
    if (arr[0] >= arr[1] && arr[0] >= arr[2]) {
      optptr = Mptr[dim1-1][dim2-1];
    }
    else if (arr[1] >= arr[0] && arr[1] >= arr[2]) {
      optptr = Iptr[dim1-1][dim2-1];
    }
    else if (arr[2] >= arr[0] && arr[2] >= arr[1]) {
      optptr = Dptr[dim1-1][dim2-1];
    }

    /// BACKTRACKING
    string newfsastr;
    int x = dim1-1, y = dim2-1 ;
    while (x != 0 || y != 0) {
      if (optptr  == 0) {
        newfsastr.insert(0,1,'m');
        x--; y--;
        optptr = Mptr[x][y] ;
      }
      else if (optptr  == 1) {
        newfsastr.insert(0,1,'m');
        x--; y--;
        optptr = Iptr[x][y] ;
      }
      else if (optptr  == 2) {
        newfsastr.insert(0,1,'m');
        x--; y--;
        optptr = Dptr[x][y] ;
      }
      else if (optptr  == 3) {
        newfsastr.insert(0,1,'d');
        x--; 
        optptr = Mptr[x][y] ;
      }
      else if (optptr  == 4) {
        newfsastr.insert(0,1,'d');
        x--; 
        optptr = Iptr[x][y] ;
      }
      else if (optptr  == 5) {
        newfsastr.insert(0,1,'d');
        x--; 
        optptr = Dptr[x][y] ;
      }
      else if (optptr  == 6) {
        newfsastr.insert(0,1,'i');
        y--;
        optptr = Mptr[x][y] ;
      }
      else if (optptr  == 7) {
        newfsastr.insert(0,1,'i');
        y--;
        optptr = Iptr[x][y] ;
      }
      else if (optptr  == 8) {
        newfsastr.insert(0,1,'i');
        y--;
        optptr = Dptr[x][y] ;
      }
    }
    return newfsastr;
}

