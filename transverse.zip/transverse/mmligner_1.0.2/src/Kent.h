/* Encoding of, and interface to, the mixture of Kent directional distributions
 * Copyright (C) 2017 Laboratory of Computational Biology, Monash University
 * (http://lcb.infotech.monash.edu.au)
 *
 * Reference:
 *   J. H. Collier, L. Allison, A. M. Lesk, P.J. Stuckey,
 *   M. Garcia de la Banda, A. S. Konagurthu.
 *   Bioinformatics 33(7):1005-1013, 2017.
 *
 * MMLigner is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MMLigner is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MMLigner. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef KENT_HPP__
#define KENT_HPP__

#include <vector>
#include <cstdlib>

//A packed Vector structure
//Can be converted to program 'native' vector structure
//when used
typedef struct __attribute__((packed)) Vector_
{
  double x;
  double y;
  double z;
} Vector_;

//A packed component structure
//Can be converted to program 'native' component structure
//when used
typedef struct __attribute__((packed)) KentComponent
{
  double weight;
  double kappa;
  double beta;
  double log_norm_const;
  Vector_ mean;
  Vector_ major;
  Vector_ minor;
} KentComponent;

//A Kent mixture model
class KentMixtureModel {
public:
  KentMixtureModel();

  //Return the number of components in the mixture model
  size_t
  componentCount() const;

  //Return a particular component (specified by the index 'which')
  //in the mixture model
  //This method returns a copy of the component
  KentComponent
  component(unsigned which) const;
  
private:
  unsigned char number_of_components; //store number of components
  std::vector<const KentComponent*> kent_component; //store pointers to rawdata
};

/*
#ifndef NDEBUG
#include <iostream>

//Do some testing
bool
_TEST_constructor();

bool
_TEST_components();

//function to run tests
int
main()
{
  unsigned error_count = 0;
  
  if (_TEST_constructor() != true) {
    std::cerr << "ERROR detected\n";
    error_count++;
  }

  if (_TEST_components() != true) {
    std::cerr << "ERROR detected\n";
    error_count++;
  }

  std::cout << error_count << " tests failed\n";
  return 0;
}
#endif //NDEBUG
*/
#endif // KENT_HPP__
