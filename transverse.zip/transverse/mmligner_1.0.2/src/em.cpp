/* Expectation maximization for refinement using I-value
 * Copyright (C) 2017 Laboratory of Computational Biology, Monash University
 * (http://lcb.infotech.monash.edu.au)
 *
 * Reference:
 *   J. H. Collier, L. Allison, A. M. Lesk, P.J. Stuckey,
 *   M. Garcia de la Banda, A. S. Konagurthu.
 *   Bioinformatics 33(7):1005-1013, 2017.
 *
 * MMLigner is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MMLigner is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MMLigner. If not, see <http://www.gnu.org/licenses/>.
 */

#include "mmligner_config.h"
#include "em.h"

void setMBlockType( vector<vector<int> > &mBlocks, size_t indx) {
    assert(indx < (mBlocks.size()-1));
    
    int prevMindxInS, prevMindxInT;
    int currMindxInS, currMindxInT;
    int nextMindxInS, nextMindxInT;

    if (indx == 0) prevMindxInS = prevMindxInT = -1;
    else {
        prevMindxInS = mBlocks[indx-1][0]+mBlocks[indx-1][2]-1;
        prevMindxInT = mBlocks[indx-1][1]+mBlocks[indx-1][2]-1;
    }
    
    currMindxInS = mBlocks[indx][0];
    currMindxInT = mBlocks[indx][1];
    
    //check if the left side of the current match block is i*/d*/i*d*
    int lstate = -1;
    if (currMindxInS == 0 && currMindxInT == 0) { // if fsastr starts with an m
        lstate = 0;
    }
    else if (prevMindxInT < currMindxInT-1
            && prevMindxInS == currMindxInS-1) { // if insertion of len >= 1
        lstate = 1;
    }
    else if (prevMindxInS < currMindxInS-1
            && prevMindxInT == currMindxInT-1) { // if deletion of len >= 1
        lstate = 2;
    }
    else if (prevMindxInS < currMindxInS-1
            && prevMindxInT < currMindxInT-1) { // if in-del of len >= 1
        lstate = 3;
    }
    else {
        //printMBlocks(mBlocks);
        assert(1);
    }
    //check if the right side of the current match block is i*/d*/i*d*
    currMindxInS = mBlocks[indx][0]+mBlocks[indx][2]-1;
    currMindxInT = mBlocks[indx][1]+mBlocks[indx][2]-1;

    nextMindxInS = mBlocks[indx+1][0]; 
    nextMindxInT = mBlocks[indx+1][1];
    int rstate = -1;
    if (currMindxInS == nextMindxInS-1 && currMindxInT == nextMindxInT-1) { // if fsastr ends with an m
        rstate = 0;

    }
    else if (currMindxInT < nextMindxInT-1
            && currMindxInS == nextMindxInS-1) { // if insertion of len >= 1
        rstate = 1;
    }
    else if (currMindxInS < nextMindxInS-1
            && currMindxInT == nextMindxInT-1) { // if insertion of len >= 1
        rstate = 2;
    }
    else if (currMindxInS < nextMindxInS-1
            && currMindxInT < nextMindxInT-1) { // if in-del of len >= 1
        rstate = 3;
    }
    else {
        //printMBlocks(mBlocks);
        assert(1);
    }
    // MATCHED BLOCK TYPES
    // 0:     m* // 1:     m*i* // 2:     m*d*   // 3:     m*i*d*   
    // 4:   i*m* // 5:   i*m*i* // 6:   i*m*d*   // 7:   i*m*i*d* 
    // 8:   d*m* // 9:   d*m*i* //10:   d*m*d*   //11:   d*m*i*d* 
    //12: i*d*m* //13: i*d*m*i* //14: i*d*m*d*   //15: i*d*m*i*d* 
    assert(mBlocks[indx].size() == 3 || mBlocks[indx].size() == 4);
    /* // debug
    cout << "!!! " << lstate << " " << rstate << " " << lstate*4+rstate << endl;
    cout << "\t" << prevMindxInS << " " <<prevMindxInT << endl;
    cout << "\t" << currMindxInS << " " <<currMindxInT << endl;
    cout << "\t" << nextMindxInS << " " <<nextMindxInT << endl;
    */
    if (mBlocks[indx].size() == 4) mBlocks[indx][3] = lstate*4+rstate;
    else mBlocks[indx].push_back(lstate*4+rstate);
}

void printMBlocks(vector<vector<int> > mBlocks) {
    cout << "====================\n";
    for (size_t i =0; i < mBlocks.size()-1; i++) {
        cout << mBlocks[i][0] << " " << mBlocks[i][1] << " " << mBlocks[i][2] << " " << mBlocks[i][3] << endl;
    }
    cout << "------\n";
    for (size_t i = 0 ; i < mBlocks[mBlocks.size()-1].size(); i++) {
        cout << mBlocks[mBlocks.size()-1][i] << " ";
    }
    cout << endl;
    cout << "====================\n";
}


vector<vector<int> > findMatchedBlocks(string fsastr) {
    size_t pos = 0;
    int scntr = -1;
    int tcntr = -1;
    vector<vector<int> > mBlocks; //each row stores (indxInS,indxInT,len,type)
    while (pos < fsastr.length()) {
        if (fsastr[pos] == '|') {
            pos++;
            continue;
        }

        else if (fsastr[pos] == 'i') {
            tcntr++;
            pos++;
        }
        else if (fsastr[pos] == 'd'){
            scntr++;
            pos++;
        }
        else {
            assert (fsastr[pos] == 'm');
            vector<int> row;
            row.push_back(scntr+1);
            row.push_back(tcntr+1);
            //find len
            int len = 0;
            while(fsastr[pos] == 'm' && pos < fsastr.length()) {
                len++;
                scntr++; tcntr++;
                pos++;
            }
            row.push_back(len);
            // type computed over a separate loop -- see few lines below
            
            

            //push the four-tuple row into mBlocks vector
            mBlocks.push_back(row);
        }
    }
    //last row is a special row. 
    //[0] stores S.size()
    //[1] stores T.size()
    //[2] stores 0
    //[3] stores nHinges
    //[4,...] stores location of hinges indx on alignment columns
    vector<int>  lastrow;
    lastrow.push_back(++scntr);
    lastrow.push_back(++tcntr);
    lastrow.push_back(0);
    size_t nHinges = getnHinges(fsastr);
    lastrow.push_back(nHinges);
    vector<int> positions = getHingePositions(fsastr);
    assert (positions.size() == nHinges);
    for (size_t i = 0; i < nHinges; i++)
        lastrow.push_back(positions[i]);

    mBlocks.push_back(lastrow);


    //compute type of mBlock and push_back at the end of each row/block
    for (size_t i =0; i < mBlocks.size()-1; i++) { //ignore last block--special
        setMBlockType(mBlocks,i);
    }

    //printMBlocks(mBlocks);
    return mBlocks;
}

string mBlocks2FSAString(vector<vector<int> >mBlocks){
    string fsastr = "";
    //left terminal gaps
    for (ssize_t j = 0; j < mBlocks[0][1]; j++) fsastr += 'i';
    for (ssize_t j = 0; j < mBlocks[0][0]; j++) fsastr += 'd';

    size_t nMatchedBlocks = mBlocks.size()-1;
    for(size_t i = 0 ; i < nMatchedBlocks; i++) {
        for (ssize_t j = 0; j < mBlocks[i][2]; j++) fsastr += 'm';
        size_t ep_curr_mBlock_S = mBlocks[i][0]+mBlocks[i][2]-1;
        size_t ep_curr_mBlock_T = mBlocks[i][1]+mBlocks[i][2]-1;
        size_t sp_next_mBlock_S = mBlocks[i+1][0];
        size_t sp_next_mBlock_T = mBlocks[i+1][1];
        if (sp_next_mBlock_S-ep_curr_mBlock_S == 1 
                && sp_next_mBlock_T-ep_curr_mBlock_T == 1) {
            continue;
        }
        //else
        for(size_t j = ep_curr_mBlock_T+1; j < sp_next_mBlock_T; j++) fsastr += 'i';
        for(size_t j = ep_curr_mBlock_S+1; j < sp_next_mBlock_S; j++) fsastr += 'd';
    }
    return fsastr;
}

string getPerturbationMask(vector<vector<int> > mBlocks, size_t indx){
    string fsastr;
    int block_ep_S =0;
    int block_ep_T =0;
    int Slen = mBlocks[mBlocks.size()-1][0];
    int Tlen = mBlocks[mBlocks.size()-1][1];
    for(size_t i = 0 ; i < mBlocks.size(); i++) {
        for (ssize_t j = block_ep_T; j < mBlocks[i][1]; j++) fsastr.append(" ");
        for (ssize_t j = block_ep_S; j < mBlocks[i][0]; j++) fsastr.append(" ");
        if (i != indx) for (ssize_t j = 0; j < mBlocks[i][2]; j++) fsastr.append(" ");
        else for (ssize_t j = 0; j < mBlocks[i][2]; j++) fsastr.append("+");
        block_ep_S = mBlocks[i][0]+mBlocks[i][2];
        block_ep_T = mBlocks[i][1]+mBlocks[i][2];
    }
    
    for (ssize_t j = block_ep_T; j < Tlen; j++) fsastr.append("i");
    for (ssize_t j = block_ep_S; j < Slen; j++) fsastr.append("d");

    if (mBlocks[mBlocks.size()-1][3] > 0) { //if hinges exist
        for (ssize_t i =0; i < mBlocks[mBlocks.size()-1][3]; i++) { //ignore last block--special
            ssize_t offset = mBlocks[mBlocks.size()-1][i+4];
            fsastr.insert(fsastr.begin()+offset,1,'|');
        }
    }
    return (fsastr);
}


///*
string shiftMatchesSpecificMatchBlock(
 vector<vector<int> > mBlocks, 
 size_t indx, // index of the match block
 bool side,   // 0 = shift from current to prev; 
              // 1 = shift from prev to curr
 ssize_t shiftLength, // how much to extend by
 bool  &perturbationFlag
) {
    perturbationFlag = false;
    //int nMatchedBlocks = mBlocks.size()-1; // have to ignore the last row.

    if (VERBOSE) {
        cout << "shifting match ... (indx,Type,shiftLength,direction) = " 
        << indx << ", " << mBlocks[indx][3] << ", " << shiftLength 
        << ", " << (side == 0 ? "left" : "right") << " ";
    }

    if (indx==0) return mBlocks2FSAString(mBlocks);

    if(side == 0 && mBlocks[indx][2] < shiftLength) return mBlocks2FSAString(mBlocks);
    else if(side == 1 && mBlocks[indx-1][2] < shiftLength) return mBlocks2FSAString(mBlocks);

    if (side == 0) {
        if (mBlocks[indx][3] >= 4 && mBlocks[indx][3] <= 11) {
            mBlocks[indx-1][2] += shiftLength;
            mBlocks[indx][0] += shiftLength; 
            mBlocks[indx][1] += shiftLength; 
            mBlocks[indx][2] -= shiftLength; 
            perturbationFlag = true;
        }
    }
    else if (side == 1) {
        if (mBlocks[indx][3] >= 4 && mBlocks[indx][3] <= 11) {
            mBlocks[indx-1][2] -= shiftLength;
            mBlocks[indx][0] -= shiftLength; 
            mBlocks[indx][1] -= shiftLength; 
            mBlocks[indx][2] += shiftLength; 
            perturbationFlag = true;
        }
    }
    return mBlocks2FSAString(mBlocks);
}
//*/

string extendSpecificMatchBlock(
 vector<vector<int> > mBlocks, 
 size_t indx, // index of the match block
 bool side, // 0 = extend on left; 1 = extend on right
 ssize_t extensionLength, // how much to extend by
 bool  &perturbationFlag
) {
    perturbationFlag = false;
    assert(indx < (mBlocks.size()-1)); // have to ignore the last row.
    if (VERBOSE) {
        cout << "Extending .... (indx,Type,extensionLength,direction) = " 
             << indx << ", " << mBlocks[indx][3] << ", " << extensionLength 
             << ", " << (side == 0 ? "left" : "right") << " ";
    }

    int prevep_S = indx > 0 ? mBlocks[indx-1][0]+mBlocks[indx-1][2]-1 : -1;
    int prevep_T = indx > 0 ? mBlocks[indx-1][1]+mBlocks[indx-1][2]-1 : -1;

    int currsp_S = mBlocks[indx][0];
    int currsp_T = mBlocks[indx][1];
    int currep_S = mBlocks[indx][0]+mBlocks[indx][2]-1;
    int currep_T = mBlocks[indx][1]+mBlocks[indx][2]-1;
    
    int nextsp_S = mBlocks[indx+1][0];
    int nextsp_T = mBlocks[indx+1][1];

    if (side == 0 && mBlocks[indx][3] >= 12) {
        if (currsp_S-prevep_S-1 >= extensionLength 
                && currsp_T-prevep_T-1 >= extensionLength) {
            mBlocks[indx][0] -= extensionLength;
            mBlocks[indx][1] -= extensionLength;
            mBlocks[indx][2] += extensionLength;
            perturbationFlag = true;
        }
    }
    else if (side == 1 && mBlocks[indx][3]%4 == 3) {
        if (nextsp_S-currep_S-1 >= extensionLength 
                && nextsp_T-currep_T-1 >= extensionLength) {
            mBlocks[indx][2] += extensionLength;
            perturbationFlag = true;
        }
    }
    if (VERBOSE) cout << "perturbed? = " << perturbationFlag << endl; 
    return mBlocks2FSAString(mBlocks);
}

string shrinkSpecificMatchBlock(
 vector<vector<int> > mBlocks, 
 size_t indx, // index of the match block
 bool side, // 0 = shrink on left; 1 = shrink on right
 ssize_t shrinkLength, // how much to shrink by
 bool  &perturbationFlag
) {
    perturbationFlag = false;
    assert(indx < (mBlocks.size()-1)); // have to ignore the last row.
    if (VERBOSE) {
        cout << "Shrinking .... (indx,Type,shrinkLength,direction) = " 
             << indx << ", " << mBlocks[indx][3] << ", " << shrinkLength 
             << ", " << (side == 0 ? "left" : "right") << " ";
    }

    if (side == 0 && mBlocks[indx][2] >= shrinkLength) {
        if (mBlocks[indx][2] == shrinkLength) { // shrinking will evaporate this block
            mBlocks.erase(mBlocks.begin()+indx);
        }
        else {
            mBlocks[indx][0] += shrinkLength;
            mBlocks[indx][1] += shrinkLength;
            mBlocks[indx][2] -= shrinkLength;
        }
        perturbationFlag = true;
    }
    else if (side == 1 && mBlocks[indx][2] >= shrinkLength) {
        if (mBlocks[indx][2] == shrinkLength) { // shrinking will evaporate this block
            mBlocks.erase(mBlocks.begin()+indx);
        }
        else {
            mBlocks[indx][2] -= shrinkLength;
        }
        perturbationFlag = true;
    }
    if (VERBOSE) cout << "perturbed? = " << perturbationFlag << endl; 
    return mBlocks2FSAString(mBlocks);
}

string nukeSpecificMatchBlock(
 vector<vector<int> > mBlocks, 
 size_t indx, // index of the match block
 bool  &perturbationFlag
) {
    perturbationFlag = false;
    assert(indx < (mBlocks.size()-1)); // have to ignore the last row.
    if (VERBOSE) {
        cout << "Nuking .... (indx,Type) = " 
             << indx << ", " << mBlocks[indx][3] << " ";
    }

    mBlocks.erase(mBlocks.begin()+indx);
    perturbationFlag = true;
    if (VERBOSE) cout << "perturbed? = " << perturbationFlag << endl; 
    return mBlocks2FSAString(mBlocks);
}

string slideSpecificMatchBlockWithoutGaps(
 vector<vector<int> > mBlocks, 
 size_t indx, // index of the match block
 bool side, // 0 = slide S leftwards  (same as slide T rightwards; 
            // 1 = slide S rightwards (same as slide T leftwards
 size_t slideLength, // how much to slide by
 bool  &perturbationFlag
) {
    perturbationFlag = false;
    assert(indx < (mBlocks.size()-1)); // have to ignore the last row.

    if (VERBOSE) {
        cout << "Sliding .... (indx,Type,SlideLength,direction) = " 
             << indx << ", " << mBlocks[indx][3] << ", " << slideLength 
             << ", " << (side == 0 ? "left" : "right") << " ";
    }

    if (side == 0) { // move T rightwards if possible
        size_t sp_next_mBlock_S = mBlocks[indx+1][0];
        size_t sp_next_mBlock_T = mBlocks[indx+1][1];
        size_t ep_curr_mBlock_S = mBlocks[indx][0]+mBlocks[indx][2]-1;
        size_t ep_curr_mBlock_T = mBlocks[indx][1]+mBlocks[indx][2]-1;
        if (VERBOSE) {
            cout << ep_curr_mBlock_S << " "  << ep_curr_mBlock_T 
                 << " " << sp_next_mBlock_S << " " << sp_next_mBlock_T << endl;
        }

        if (ep_curr_mBlock_S+slideLength < sp_next_mBlock_S) {
            mBlocks[indx][0] += slideLength;
            perturbationFlag = true;
        }
    }
    else { //if (side == 1) that is slide T leftwards
        ssize_t sp_curr_mBlock_S = mBlocks[indx][0];
        //ssize_t sp_curr_mBlock_T = mBlocks[indx][1];
        ssize_t ep_prev_mBlock_S, ep_prev_mBlock_T;
        if (indx == 0) ep_prev_mBlock_S = ep_prev_mBlock_T = -1;
        else {
            ep_prev_mBlock_S = mBlocks[indx-1][0]+mBlocks[indx-1][2]-1;
            ep_prev_mBlock_T = mBlocks[indx-1][1]+mBlocks[indx-1][2]-1;
        }
        
        if ((ssize_t)sp_curr_mBlock_S-(ssize_t)slideLength > ep_prev_mBlock_S) {
            mBlocks[indx][0] -= slideLength;
            perturbationFlag = true;
        }
    }
    if (VERBOSE) cout << "perturbed? = " << perturbationFlag << endl; 
    return mBlocks2FSAString(mBlocks);
}


string reAlignSpecificMatchBlock(
  vector<vector<int> > mBlocks,
  size_t indx, // index of the match block
  string fsastr,
  vector<vector<double> > S,
  vector<vector<double> > T,
  double distThreshold,
  bool  &perturbationFlag
) {
    size_t nMatchedBlocks = mBlocks.size()-1;
    if (VERBOSE) {
        cout << "Realigning match block .... (indx ) "
             << indx <<  " ";
    }
    //printMBlocks(mBlocks);
    //isolate the segment i*d*m*i*d* for this matched block
    ssize_t ep_prev_S, ep_prev_T, sp_next_S, sp_next_T;
    string fsastr_prefix="", fsastr_segment="", fsastr_suffix="";
    ssize_t scntr =0, tcntr = 0;
    ssize_t segment_sp_fsastr = 0;
    ssize_t segment_ep_fsastr = 0;
    if (indx == 0) { // if first matched block
        ep_prev_S = -1;
        ep_prev_T = -1;
        sp_next_S = mBlocks[indx+1][0];
        sp_next_T = mBlocks[indx+1][1];

        if (indx+1 < nMatchedBlocks-1 && mBlocks[indx+1][2] < 15) {
            sp_next_S = mBlocks[indx+2][0];
            sp_next_T = mBlocks[indx+2][1];
        }

        //isolate fsastr into prefix and suffix of this segment
        segment_sp_fsastr = 0;
        //cout<< " * " << 0 << endl;
        ssize_t scntr =-1, tcntr = -1;
        bool flag = false;
        for (size_t i = 0; i < fsastr.length(); i++) {
            if (fsastr[i] == '|') continue;
            else if (fsastr[i] == 'm') {
                scntr++;
                tcntr++;
            }
            else if (fsastr[i] == 'd') {
                scntr++;
            }
            else if (fsastr[i] == 'i') {
                tcntr++;
            }
            //cout << i << " " << fsastr[i] << " "<< scntr << " " << tcntr << endl;
            if (scntr == sp_next_S && tcntr == sp_next_T) {
                flag = true;
                segment_ep_fsastr = i-1;
                break;
            }
        }
        if (flag == false) segment_ep_fsastr = fsastr.length()-1;
    }
    else if(indx == mBlocks.size()-2) {
        ep_prev_S = mBlocks[indx-1][0]+mBlocks[indx-1][2]-1;
        ep_prev_T = mBlocks[indx-1][1]+mBlocks[indx-1][2]-1;
     
        sp_next_S = mBlocks[indx+1][0];
        sp_next_T = mBlocks[indx+1][1];
        if (indx+1 < nMatchedBlocks-1 && mBlocks[indx+1][2] < 15) {
            sp_next_S = mBlocks[indx+2][0];
            sp_next_T = mBlocks[indx+2][1];
        }

        //isolate fsastr into prefix and suffix of this segment
        ssize_t scntr =-1, tcntr = -1;
        for (size_t i = 0; i < fsastr.length(); i++) {
            if (fsastr[i] == '|') continue;
            else if (fsastr[i] == 'm') {
                scntr++;
                tcntr++;
            }
            else if (fsastr[i] == 'd') {
                scntr++;
            }
            else if (fsastr[i] == 'i') {
                tcntr++;
            }
            //cout << i << " " << fsastr[i] << " "<< scntr << " " << tcntr << endl;
            if (scntr == ep_prev_S && tcntr == ep_prev_T) {
                //cout<< " * " << i+1 << endl;
                segment_sp_fsastr = i+1;
            }
        }
        segment_ep_fsastr = fsastr.size()-1;
        //cout<< " * " << segment_ep_fsastr << endl;
    }
    else {
        ep_prev_S = mBlocks[indx-1][0]+mBlocks[indx-1][2]-1;
        ep_prev_T = mBlocks[indx-1][1]+mBlocks[indx-1][2]-1;
     
        sp_next_S = mBlocks[indx+1][0];
        sp_next_T = mBlocks[indx+1][1];
        if (indx+1 < nMatchedBlocks-1 && mBlocks[indx+1][2] < 15) {
            sp_next_S = mBlocks[indx+2][0];
            sp_next_T = mBlocks[indx+2][1];
        }

        //isolate fsastr into prefix and suffix of this segment
        ssize_t scntr =-1, tcntr = -1;
        for (size_t i = 0; i < fsastr.length(); i++) {
            if (fsastr[i] == '|') continue;
            else if (fsastr[i] == 'm') {
                scntr++;
                tcntr++;
            }
            else if (fsastr[i] == 'd') {
                scntr++;
            }
            else if (fsastr[i] == 'i') {
                tcntr++;
            }
            //cout << i << " " << fsastr[i] << " "<< scntr << " " << tcntr << endl;
            if (scntr == ep_prev_S && tcntr == ep_prev_T) {
                //cout<< " * " << i+1 << endl;
                segment_sp_fsastr = i+1;
            }
            if (scntr == sp_next_S && tcntr == sp_next_T) {
                //cout<< " * " << i-1 << endl;
                segment_ep_fsastr = i-1;
                break;
            }
        }
    }
    //copy prefix fsastr
    for (ssize_t i = 0; i < segment_sp_fsastr; i++) fsastr_prefix += fsastr[i];
    //copy segment fsastr and coords
    vector<vector<double> > segment_coords_S;
    vector<vector<double> > segment_coords_T;
    scntr = ep_prev_S;
    tcntr = ep_prev_T;
    for (ssize_t i = segment_sp_fsastr; i <= segment_ep_fsastr; i++) {
        if (fsastr[i] == '|') continue;
        else if (fsastr[i] == 'm') {
            scntr++;
            tcntr++;
            segment_coords_S.push_back(S[scntr]);
            segment_coords_T.push_back(T[tcntr]);
            fsastr_segment += fsastr[i];
        }
        else if (fsastr[i] == 'd') {
            scntr++;
            segment_coords_S.push_back(S[scntr]);
            fsastr_segment += fsastr[i];
        }
        else if (fsastr[i] == 'i') {
            tcntr++;
            segment_coords_T.push_back(T[tcntr]);
            fsastr_segment += fsastr[i];
        }

    }
    //cout << "segment\n" << fsastr_segment << endl;
    //copy suffix fsastr
    for (size_t i = segment_ep_fsastr+1; i < fsastr.length(); i++) fsastr_suffix += fsastr[i];
    //cout << "suffix\n" << fsastr_suffix << endl;

    //align
    fsastr_segment = alignClosestAfterSuperposition(fsastr_segment,segment_coords_S,segment_coords_T,distThreshold);
    fsastr = fsastr_prefix+fsastr_segment+fsastr_suffix;
    assert(sanityCheckAlignment(fsastr,S,T));
    perturbationFlag = true;

    if (VERBOSE) cout << "perturbed? = " << perturbationFlag << endl; 
    return fsastr;
}



string EMClosest(string fsastr, vector<vector<double> > S, vector<vector<double> >T) {
   string fsastr_prev = fsastr;
   double dthresh = 5;
   size_t nIters = 0;
   while (nIters < 26) {
       //cout << "---> " << canonicalizefsa(fsastr_prev) << endl;
        string fsastr_curr = alignClosestAfterSuperposition(fsastr_prev,S,T,dthresh);
        if (fsastr_prev.compare(fsastr_curr) == 0)  break;
        fsastr_prev = fsastr_curr;
        nIters++;
        //sleep(1);
   }
   return canonicalizefsa(fsastr_prev);
}

vector<int> worstDistancePairInMBlock(
 vector<vector<int> > mBs,
 vector<vector<double> > S,
 vector<vector<double> > T,
 double distThreshold) {
    size_t nMatchedBlocks = mBs.size()-1; 
    vector<int> mWorstDist;
    for (size_t i = 0; i < nMatchedBlocks; i++) {
        double maxdist = distThreshold;
        int maxdistIndxInBlock = -1;
        for (ssize_t j = 1; j < mBs[i][2]-1; j++) { //ignore first/last m in block
            double dist = 0;
            double Si[3];
            double Tj[3];
            dv2da(S[mBs[i][0]+j],Si);
            dv2da(T[mBs[i][1]+j],Tj);
            dist += normAminusB(Si,Tj);

            if (dist > maxdist) {
                maxdist = dist;
                maxdistIndxInBlock = j;
            }
        }
        mWorstDist.push_back(maxdistIndxInBlock);
    }
    assert (mWorstDist.size()+1 == mBs.size());
    return mWorstDist;
}

string assessAlignment(  
 string fsastr,
 vector<vector<double> > S, //full coordinates of structure S 
 vector<vector<double> > T, //full coordinates of structure T
 double &compression
 ){
    vector<vector<int> > mBs = findMatchedBlocks(fsastr);
    size_t nMatchedBlocks = mBs.size()-1; 
    if (nMatchedBlocks > 2) return fsastr;
    vector<double> stats = computeIvalue(fsastr,S,T,false);
    size_t nMatches    = (size_t)stats[ALIGNSTATS_IDX_NMATCH];
    compression = stats[ALIGNSTATS_IDX_COMPRESSION];
    size_t S_size  = (size_t)stats[ALIGNSTATS_IDX_NS];
    size_t T_size  = (size_t)stats[ALIGNSTATS_IDX_NT];
    size_t minsize = S_size>T_size?T_size:S_size;
    double percentcoverage_S  = (double)nMatches/(double)S_size; 
    double percentcoverage_T  = (double)nMatches/(double)T_size; 
    double maxpercentcoverage = percentcoverage_S>percentcoverage_T
                                    ? percentcoverage_S
                                    : percentcoverage_T;
    if (  (nMatches < 50 && maxpercentcoverage < 0.25 && nMatchedBlocks <=2)
        ||(minsize  < 75 && maxpercentcoverage < 0.60 && nMatchedBlocks <=3) ) {
        compression = -1;
        return getUnalignedFSAString(S_size,T_size);
    }
    else return fsastr;
}
string EMivalue(  
 string fsastr,
 vector<vector<double> > S, //full coordinates of structure S 
 vector<vector<double> > T, //full coordinates of structure T
 double &compression
 ) {
    vector<double> codelens = computeIvalue(fsastr,S,T,false);
    double ivalue_curr = codelens[ALIGNSTATS_IDX_IVALUE];
    compression = codelens[ALIGNSTATS_IDX_COMPRESSION];

    double ivalue_best = ivalue_curr;
    string fsastr_best = fsastr;

    size_t nIters = 50;
    bool left =0;
    bool right=1;
    bool pflag = false;
    string pfsastr;
    ssize_t pbestmBlockIndx = -1;
    //double pivalue;
    size_t i;
    size_t nAcceptedExtends =0, nAcceptedShrinks=0, nAcceptedshifts=0, nAcceptedRealigns=0;//, nAcceptedRealigns2=0;
    for (i = 0; i < nIters; i++) {
        if(VERBOSE) {
            cout << "\n\nNew iteration\n";
            cout << fsastr << endl;
        }
        if (i==0) printPercentCompleted(i,nIters,8,0);
        else printPercentCompleted(i,nIters,8,9);

        vector<double> zztmp = computeIvalue(fsastr,S,T,false);
        vector<vector<int> > mBs = findMatchedBlocks(fsastr);
        size_t nMatchedBlocks = mBs.size()-1; // ignore last 
        double rmsd = superposeTonSUsingAlignment(fsastr,S,T);
        vector<int> mWorstDist = worstDistancePairInMBlock(mBs,S,T,rmsd/sqrt(3));
        for (size_t j = 0; j < nMatchedBlocks; j++) {
            for (ssize_t l = 1; l < 4; l++) { // perturbation length
                pflag = false;
                pfsastr = extendSpecificMatchBlock(mBs,j,left,l,pflag);
                assert(sanityCheckAlignment(pfsastr,S,T));
                if (pflag) {
                    vector<double> pcodelens = computeIvalue(pfsastr,S,T,false);
                    double pivalue = pcodelens[ALIGNSTATS_IDX_IVALUE];
                    if (pivalue < ivalue_best) {
                        nAcceptedExtends++;
                        ivalue_best = pivalue;
                        compression = pcodelens[ALIGNSTATS_IDX_COMPRESSION];
                        fsastr_best = pfsastr;
                        pbestmBlockIndx = j;
                        if (VERBOSE) {
                            cout << getPerturbationMask(mBs,j) << endl 
                                << fsastr << endl;
                            cout << getPerturbationMask(mBs,j) << endl 
                                << fsastr_best << endl;
                            cout << "ivalue "<< ivalue_best << endl;
                            cout << "(nMatches,rmsd) = " 
                                << getnMatches(fsastr_best) <<  " " 
                                << getRMSD(fsastr_best,S,T) << endl; 
                        }
                    }
                }
                pflag = false;
                pfsastr = extendSpecificMatchBlock(mBs,j,right,l,pflag);
                assert(sanityCheckAlignment(pfsastr,S,T));
                if (pflag) {
                    vector<double> pcodelens = computeIvalue(pfsastr,S,T,false);
                    double pivalue = pcodelens[ALIGNSTATS_IDX_IVALUE];
                    if (pivalue < ivalue_best) {
                        nAcceptedExtends++;
                        ivalue_best = pivalue;
                        compression = pcodelens[ALIGNSTATS_IDX_COMPRESSION];
                        fsastr_best = pfsastr;
                        pbestmBlockIndx = j;
                        if (VERBOSE) {
                            cout << getPerturbationMask(mBs,j) << endl 
                                << fsastr << endl;
                            cout << getPerturbationMask(mBs,j) << endl 
                                << fsastr_best << endl;
                            cout << "ivalue "<< ivalue_best << endl;
                            cout << "(nMatches,rmsd) = " 
                                << getnMatches(fsastr_best) <<  " " 
                                << getRMSD(fsastr_best,S,T) << endl; 
                        }
                    }
                }
                pflag = false;
                pfsastr = shrinkSpecificMatchBlock(mBs,j,left,l,pflag);
                assert(sanityCheckAlignment(pfsastr,S,T));
                if (pflag) {
                    vector<double> pcodelens = computeIvalue(pfsastr,S,T,false);
                    double pivalue = pcodelens[ALIGNSTATS_IDX_IVALUE];
                    if (pivalue < ivalue_best) {
                        nAcceptedShrinks++;
                        ivalue_best = pivalue;
                        compression = pcodelens[ALIGNSTATS_IDX_COMPRESSION];
                        fsastr_best = pfsastr;
                        pbestmBlockIndx = j;
                        if (VERBOSE) {
                            cout << getPerturbationMask(mBs,j) << endl 
                                << fsastr << endl;
                            cout << getPerturbationMask(mBs,j) << endl 
                                << fsastr_best << endl;
                            cout << "ivalue "<< ivalue_best << endl;
                            cout << "(nMatches,rmsd) = " 
                                << getnMatches(fsastr_best) <<  " " 
                                << getRMSD(fsastr_best,S,T) << endl; 
                        }
                    }
                }
                pflag = false;
                pfsastr = shrinkSpecificMatchBlock(mBs,j,right,l,pflag);
                assert(sanityCheckAlignment(pfsastr,S,T));
                if (pflag) {
                    vector<double> pcodelens = computeIvalue(pfsastr,S,T,false);
                    double pivalue = pcodelens[ALIGNSTATS_IDX_IVALUE];
                    if (pivalue < ivalue_best) {
                        nAcceptedShrinks++;
                        ivalue_best = pivalue;
                        compression = pcodelens[ALIGNSTATS_IDX_COMPRESSION];
                        fsastr_best = pfsastr;
                        pbestmBlockIndx = j;
                        if (VERBOSE) {
                            cout << getPerturbationMask(mBs,j) << endl 
                                << fsastr << endl;
                            cout << getPerturbationMask(mBs,j) << endl 
                                << fsastr_best << endl;
                            cout << "ivalue "<< ivalue_best << endl;
                            cout << "(nMatches,rmsd) = " 
                                << getnMatches(fsastr_best) <<  " " 
                                << getRMSD(fsastr_best,S,T) << endl; 
                        }
                    }
                }
                pflag = false;
                pfsastr = shiftMatchesSpecificMatchBlock(mBs,j,left,l,pflag);
                assert(sanityCheckAlignment(pfsastr,S,T));
                if (pflag) {
                    vector<double> pcodelens = computeIvalue(pfsastr,S,T,false);
                    double pivalue = pcodelens[ALIGNSTATS_IDX_IVALUE];
                    if (pivalue < ivalue_best) {
                        nAcceptedshifts++;
                        ivalue_best = pivalue;
                        compression = pcodelens[ALIGNSTATS_IDX_COMPRESSION];
                        fsastr_best = pfsastr;
                        pbestmBlockIndx = j;
                        if (VERBOSE) {
                            cout << getPerturbationMask(mBs,j) << endl 
                                << fsastr << endl;
                            cout << getPerturbationMask(mBs,j) << endl 
                                << fsastr_best << endl;
                            cout << "ivalue "<< ivalue_best << endl;
                            cout << "(nMatches,rmsd) = " 
                                << getnMatches(fsastr_best) <<  " " 
                                << getRMSD(fsastr_best,S,T) << endl; 
                        }
                    }
                }
                pflag = false;
                pfsastr = shiftMatchesSpecificMatchBlock(mBs,j,right,l,pflag);
                assert(sanityCheckAlignment(pfsastr,S,T));
                if (pflag) {
                    vector<double> pcodelens = computeIvalue(pfsastr,S,T,false);
                    double pivalue = pcodelens[ALIGNSTATS_IDX_IVALUE];
                    if (pivalue < ivalue_best) {
                        nAcceptedshifts++;
                        ivalue_best = pivalue;
                        compression = pcodelens[ALIGNSTATS_IDX_COMPRESSION];
                        fsastr_best = pfsastr;
                        pbestmBlockIndx = j;
                        if (VERBOSE) {
                            cout << getPerturbationMask(mBs,j) << endl 
                                << fsastr << endl;
                            cout << getPerturbationMask(mBs,j) << endl 
                                << fsastr_best << endl;
                            cout << "ivalue "<< ivalue_best << endl;
                            cout << "(nMatches,rmsd) = " 
                                << getnMatches(fsastr_best) <<  " " 
                                << getRMSD(fsastr_best,S,T) << endl; 
                        }
                    }
                }
                pflag = false;
                pfsastr = slideSpecificMatchBlockWithoutGaps(mBs,j,left,l,pflag);
                assert(sanityCheckAlignment(pfsastr,S,T));
                if (pflag) {
                    vector<double> pcodelens = computeIvalue(pfsastr,S,T,false);
                    double pivalue = pcodelens[ALIGNSTATS_IDX_IVALUE];
                    if (pivalue < ivalue_best) {
                        ivalue_best = pivalue;
                        compression = pcodelens[ALIGNSTATS_IDX_COMPRESSION];
                        fsastr_best = pfsastr;
                        pbestmBlockIndx = j;
                        if (VERBOSE) {
                            cout << getPerturbationMask(mBs,j) << endl 
                                << fsastr << endl;
                            cout << getPerturbationMask(mBs,j) << endl 
                                << fsastr_best << endl;
                            cout << "ivalue "<< ivalue_best << endl;
                            cout << "(nMatches,rmsd) = " 
                                << getnMatches(fsastr_best) <<  " " 
                                << getRMSD(fsastr_best,S,T) << endl; 
                        }
                    }
                }
                pflag = false;
                pfsastr = slideSpecificMatchBlockWithoutGaps(mBs,j,right,l,pflag);
                assert(sanityCheckAlignment(pfsastr,S,T));
                if (pflag) {
                    vector<double> pcodelens = computeIvalue(pfsastr,S,T,false);
                    double pivalue = pcodelens[ALIGNSTATS_IDX_IVALUE];
                    if (pivalue < ivalue_best) {
                        ivalue_best = pivalue;
                        compression = pcodelens[ALIGNSTATS_IDX_COMPRESSION];
                        fsastr_best = pfsastr;
                        pbestmBlockIndx = j;
                        if (VERBOSE) {
                            cout << getPerturbationMask(mBs,j) << endl 
                                << fsastr << endl;
                            cout << getPerturbationMask(mBs,j) << endl 
                                << fsastr_best << endl;
                            cout << "ivalue "<< ivalue_best << endl;
                            cout << "(nMatches,rmsd) = " 
                                << getnMatches(fsastr_best) <<  " " 
                                << getRMSD(fsastr_best,S,T) << endl; 
                        }
                    }
                }
            }
            pflag = false;
            //cout << fsastr << endl;
            //cout << i << " " << j << endl;
            pfsastr = reAlignSpecificMatchBlock(mBs,j,fsastr,S,T,(double)-1,pflag);
            assert(sanityCheckAlignment(pfsastr,S,T));
            if (pflag) {
                vector<double> pcodelens = computeIvalue(pfsastr,S,T,false);
                double pivalue = pcodelens[ALIGNSTATS_IDX_IVALUE];
                if (pivalue < ivalue_best) {
                    nAcceptedRealigns++;
                    ivalue_best = pivalue;
                    compression = pcodelens[ALIGNSTATS_IDX_COMPRESSION];
                    fsastr_best = pfsastr;
                    pbestmBlockIndx = j;
                    if (VERBOSE) {
                        cout << getPerturbationMask(mBs,j) << endl 
                            << fsastr << endl;
                        cout << getPerturbationMask(mBs,j) << endl 
                            << fsastr_best << endl;
                        cout << "ivalue "<< ivalue_best << endl;
                        cout << "(nMatches,rmsd) = " 
                            << getnMatches(fsastr_best) <<  " " 
                            << getRMSD(fsastr_best,S,T) << endl; 
                        cout << "Accepted" << endl; 
                    }
                }
            }
        }
        if (fsastr.compare(fsastr_best) == 0) break;
        fsastr = fsastr_best;
        if (VERBOSE) {
            cout << fsastr_best << endl;
            cout << "index = " << pbestmBlockIndx << endl;
            cout << "BEST SO FAR" << endl;
            cout << "ivalue "<< ivalue_best << endl;
            cout << "(nMatches,rmsd) = " 
                 << getnMatches(fsastr_best) <<  " " 
                 << getRMSD(fsastr_best,S,T) << endl; 
            cout << endl;
        }
        pbestmBlockIndx = -1;
    }
    // In the final pass attempt to delete every single matched block
    // and see if compression improves
    fsastr = fsastr_best;
    for (i = 0; i < nIters; i++) {
        vector<double> zztmp = computeIvalue(fsastr_best,S,T,false);
        vector<vector<int> > mBs = findMatchedBlocks(fsastr_best);
        size_t nMatchedBlocks = mBs.size()-1; // ignore last 
        for (size_t j = 0; j < nMatchedBlocks; j++) {
                pflag = false;
                pfsastr = nukeSpecificMatchBlock(mBs,j,pflag);
                assert(sanityCheckAlignment(pfsastr,S,T));
                if (pflag) {
                    vector<double> pcodelens = computeIvalue(pfsastr,S,T,false);
                    double pivalue = pcodelens[ALIGNSTATS_IDX_IVALUE];
                    if (pivalue < ivalue_best) {
                        nAcceptedExtends++;
                        ivalue_best = pivalue;
                        compression = pcodelens[ALIGNSTATS_IDX_COMPRESSION];
                        fsastr_best = pfsastr;
                        pbestmBlockIndx = j;
                        if (VERBOSE) {
                            cout << getPerturbationMask(mBs,j) << endl 
                                << fsastr << endl;
                            cout << getPerturbationMask(mBs,j) << endl 
                                << fsastr_best << endl;
                            cout << "ivalue "<< ivalue_best << endl;
                            cout << "(nMatches,rmsd) = " 
                                << getnMatches(fsastr_best) <<  " " 
                                << getRMSD(fsastr_best,S,T) << endl; 
                        }
                    }
                }
        }
        if (fsastr.compare(fsastr_best) == 0) break;
        fsastr = fsastr_best;
        if (VERBOSE) {
            cout << fsastr_best << endl;
            cout << "index = " << pbestmBlockIndx << endl;
            cout << "BEST SO FAR" << endl;
            cout << "ivalue "<< ivalue_best << endl;
            cout << "(nMatches,rmsd) = " 
                 << getnMatches(fsastr_best) <<  " " 
                 << getRMSD(fsastr_best,S,T) << endl; 
            cout << endl;
        }
        pbestmBlockIndx = -1;
    }
    //fsastr_best = assessAlignment(fsastr_best,S,T,compression);
    printPercentCompleted(nIters,nIters,8,9);

    return fsastr_best;
}

string expectationMaximization(  
 string seedalgn_fsastr,
 vector<vector<double> > S, //full coordinates of structure S 
 vector<vector<double> > T, //full coordinates of structure T
 double &compression
 ) {
    string fsastr = seedalgn_fsastr;
    vector<double> seedalgnstats = computeIvalue(seedalgn_fsastr,S,T,false);
    double seedalgn_cmp = seedalgnstats[ALIGNSTATS_IDX_COMPRESSION];
    fsastr = EMClosest(fsastr,S,T);
    assert(sanityCheckAlignment(fsastr,S,T));
    fsastr = EMivalue(fsastr,S,T,compression);
    if (compression < seedalgn_cmp) return seedalgn_fsastr;
    else return fsastr;
}
