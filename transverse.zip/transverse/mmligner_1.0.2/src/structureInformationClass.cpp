/* Generic interface for reading and storing protein structure data
 * Copyright (C) 2017 Laboratory of Computational Biology, Monash University
 * (http://lcb.infotech.monash.edu.au)
 *
 * Reference:
 *   J. H. Collier, L. Allison, A. M. Lesk, P.J. Stuckey,
 *   M. Garcia de la Banda, A. S. Konagurthu.
 *   Bioinformatics 33(7):1005-1013, 2017.
 *
 * MMLigner is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MMLigner is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MMLigner. If not, see <http://www.gnu.org/licenses/>.
 */

#include  "structureInformationClass.h"

structureInformationClass::structureInformationClass() {

}
structureInformationClass::structureInformationClass(string fname, string chains) {
   /* parse coordinates the given structure */ 
   ostringstream oss;
   oss << "Parsing Brookhaven PDB " << setw(8) << "...";
   if (fname.length() > 15) {
     oss << fname.substr(fname.length()-15);
   } else {
     oss << fname;
   }
   if (chains.length() > 0) oss << ":" << chains;
   printToTerminalMsg(oss);

   PDB_t pdb(fname.c_str());
   string allchainIDs = pdb.getAllChainIDs(0);
   
   if (chains.length() == 0) chains = allchainIDs;  
   else {
       //ensure the passed chainIDs exist in the pdb
       bool continueFlag = true;
       for (size_t i = 0; i < chains.length(); i++) {
           size_t pos = allchainIDs.find(chains[i]);
           if (pos == string::npos) {
               if (continueFlag == true)  cerr << "\n";
               cerr << "::PDBParseError:: chain '" 
                    << getTerminalColorString(chains.substr(i,1),31) 
                    << "' not found\n";
               continueFlag = false;
           }
       }
       if (!continueFlag) exit(1);
   }

   for (size_t i = 0; i < chains.length(); i++) {
      vector<vector<double> > coords;
      string aaseq;
      vector<string> resiLabels;
      vector<uint32_t> resiIds;
      pdb.getCACoordsOfChain(0,chains[i],coords,aaseq,resiLabels,resiIds);
   
      assert(coords.size()  == aaseq.length());
      assert(coords.size()  == resiLabels.size());
      assert(resiIds.size() == resiLabels.size());
      this->coords.insert(this->coords.end(),coords.begin(),coords.end());
      this->aaseq.insert(this->aaseq.end(),aaseq.begin(),aaseq.end());
      this->resiLabels.insert(this->resiLabels.end(),resiLabels.begin(),resiLabels.end());
      this->resiIds.insert(this->resiIds.end(),resiIds.begin(),resiIds.end());
   }
   this->pdbobj = pdb;
   
   size = this->coords.size();
   cout << " nResi = " << setw(5) << size << " ";
   printToTerminalMsgStatus("OK");
}

bool readStructures(
 vector<string> &fn,
 vector<string> &cid,
 structureInformationClass &struct_S,
 structureInformationClass &struct_T
) {
  bool kramaflag = false; 
      
  structureInformationClass S0(fn[0],cid[0]);
  structureInformationClass S1(fn[1],cid[1]);
  
  structureInformationClass tmp;

  if (S1.size > S0.size) {
      tmp= S0;
      S0 = S1;
      S1 =tmp;
      kramaflag = true;
  }
  else if (S0.size == S1.size) {
      if (fn[0].compare(fn[1]) < 0) {
        tmp= S0;
        S0 = S1;
        S1 =tmp;
        kramaflag = true;
      }
      else if (fn[0].compare(fn[1]) == 0) {
          if (cid[0].compare(cid[1]) < 0) {
            tmp= S0;
            S0 = S1;
            S1 =tmp;
            kramaflag = true;
          }
      }
  }
  struct_S = S0;
  struct_T = S1;

  assert(struct_S.size >= struct_T.size);
  return kramaflag;
}
