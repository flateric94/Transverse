/* Interface for dealing with maximal fragment pairs (MFPs)
 * Copyright (C) 2017 Laboratory of Computational Biology, Monash University
 * (http://lcb.infotech.monash.edu.au)
 *
 * Reference:
 *   J. H. Collier, L. Allison, A. M. Lesk, P.J. Stuckey,
 *   M. Garcia de la Banda, A. S. Konagurthu.
 *   Bioinformatics 33(7):1005-1013, 2017.
 *
 * MMLigner is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MMLigner is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MMLigner. If not, see <http://www.gnu.org/licenses/>.
 */

#include "MFPClass.h"
MFPClass_t::MFPClass_t() {
   setflag = false;
}

MFPLibraryClass_t::MFPLibraryClass_t() {
   return;
}


MFPLibraryClass_t::MFPLibraryClass_t(
 structureInformationClass &struct1, 
 structureInformationClass &struct2,
 float rmsdthreshmax, 
 size_t minlen,
 string option __attribute__((unused))// always pass "RMSD_VARYING"
) {
   assert(option.compare("RMSD_VARYING")==0);
   float rmsdthresh;
   ostringstream oss;
   oss << "...building MFP Library " ;
   printToTerminalMsg(oss);
   cout << setw(15) << " ";
   strsize.push_back(struct1.size);
   strsize.push_back(struct2.size);
   MFPClass_t temp;

   vector<vector<double> > coords1 = struct1.coords;
   vector<vector<double> > coords2 = struct2.coords;

   vector<vector<size_t> > history(coords1.size(),vector<size_t> (coords2.size(),0));

   size_t PERMISSABLE_FAILS = 1;
   size_t cntr = 0;
   Superpose3DClass tmpsupobj;
   for (size_t i = 0; i < struct1.size-minlen+1; i++) {
      for (size_t j = 0; j < struct2.size-minlen+1; j++) {
         MFPClass_t superposable_fp;
         size_t nFails = 0;
         bool newsupflag = true;
         for (size_t l = minlen; i+l-1<struct1.size&&j+l-1<struct2.size;l++) {
            if  (l <= 5) rmsdthresh =  0.5;
            else if (l <= 7) rmsdthresh = 0.75;
            else if (l == 8) rmsdthresh = 1;
            else if (l == 9) rmsdthresh = 1.25;
            else if (l == 10) rmsdthresh = 1.5;
            else if (l == 11) rmsdthresh = 1.75;
            else rmsdthresh = rmsdthreshmax; 

            if (history[i][j] != 0 && history[i][j] >= l)  l = history[i][j]+1; 

            if (i+l-1 >= struct1.size || j+l-1 >= struct2.size) break; 
            if (newsupflag == true) {
               Superpose3DClass supobj(coords1,coords2,i,j,l);
               float rmsd = supobj.getRMSD();
               cntr++;

               if (rmsd > rmsdthresh) nFails++;
               else if ( rmsd <= rmsdthresh) {
                  superposable_fp.setflag = true;
                  superposable_fp.locus.push_back(i);
                  superposable_fp.locus.push_back(j);
                  superposable_fp.length  = l;
                  superposable_fp.rmsd    = rmsd;
                  superposable_fp.supobj  = supobj;
                  newsupflag = false;
                  nFails = 0;
               }
               if (nFails > PERMISSABLE_FAILS ) break;
            }
            else { // if (newsupflag == false)
               SuffStatClass ssobj = (nFails==0)?
                  superposable_fp.supobj.getSufficientStatistics():
                  tmpsupobj.getSufficientStatistics();

               Superpose3DClass supobj(ssobj,coords1[i+l-1],coords2[j+l-1],'+');
               cntr++;
               float rmsd = supobj.getRMSD();

               if (rmsd > rmsdthresh) {
                  nFails++;
                  if (nFails > PERMISSABLE_FAILS ) break;
                  tmpsupobj = supobj;
               }
               //else
               else if ( rmsd <= rmsdthresh) {
                  superposable_fp.locus[0] = i;
                  superposable_fp.locus[1] = j;
                  superposable_fp.length  = l;
                  superposable_fp.rmsd    = rmsd;
                  superposable_fp.supobj  = supobj;
                  nFails = 0;
               }
            }
            //if (l >0.3*struct1.size || l > 0.3*struct2.size) break;
         }
         if (superposable_fp.setflag == false ) continue;
         //else 
         // compute coverage of each frag in the MFP and remember it.
         float tmp = (float)superposable_fp.length/struct1.size;
         superposable_fp.coverage.push_back(tmp);
         tmp = (float)superposable_fp.length/struct2.size;
         superposable_fp.coverage.push_back(tmp);

         // compute score of MFP:
         if (superposable_fp.length >= 3*minlen 
               || superposable_fp.coverage[0] >= 0.3
               || superposable_fp.coverage[1] >= 0.3
         ){
            assert(superposable_fp.length >= minlen);
            size_t nTiles = ceil((float)superposable_fp.length/minlen);
            size_t scoremultiplier = choose3(nTiles);
            superposable_fp.score 
               =  combinatorialTopofitScore( 3*minlen,
                     superposable_fp.rmsd,scoremultiplier);
         }
         else {
            superposable_fp.score = 0;
         }

         mfpLibrary.push_back(superposable_fp);
         for (size_t k = 0; k < superposable_fp.length; k++) 
            history[i+k][j+k] = superposable_fp.length-k;
      }
   }
   printToTerminalMsgStatus("OK");
}



MFPLibraryClass_t::MFPLibraryClass_t(vector<MFPClass_t> &mfps, size_t str1size, size_t str2size) {
   mfpLibrary = mfps;
   strsize.push_back(str1size);
   strsize.push_back(str2size);
}

vector<MFPClass_t> MFPLibraryClass_t::getMFPLibrary() {
   return mfpLibrary;
}

MFPClass_t MFPLibraryClass_t::getLargestMFP() {
   size_t l = 0;

   MFPClass_t tmp;
   for (size_t i = 0; i < mfpLibrary.size(); i++) {
      if (mfpLibrary[i].length > l) {
         l = mfpLibrary[i].length;
         tmp = mfpLibrary[i];
      }
   }
   return tmp;
}

void MFPLibraryClass_t::print(string fname) {
   ofstream out(fname.c_str(), ios::out);
   for (size_t i = 0 ; i < mfpLibrary.size(); i++) {
      out << setw(4) << mfpLibrary[i].locus[0] << " ";
      out << setw(4) << mfpLibrary[i].locus[1] << " ";
      out << setw(4) << mfpLibrary[i].length << " ";
      out << fixed;
      out << setw(4) << setprecision(2) << mfpLibrary[i].rmsd << " ";
      out << setw(8) << setprecision(4) << mfpLibrary[i].score << " ";
      out << setw(4) << setprecision(2) << mfpLibrary[i].coverage[0] << " ";
      out << setw(4) << setprecision(2) << mfpLibrary[i].coverage[1] << endl;
   }
   out.close();
}

size_t MFPLibraryClass_t::getMFPLibrarySize() {
    return mfpLibrary.size();
}

