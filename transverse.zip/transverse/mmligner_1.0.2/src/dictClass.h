/* Defines a MFP dictionary
 * Copyright (C) 2017 Laboratory of Computational Biology, Monash University
 * (http://lcb.infotech.monash.edu.au)
 *
 * Reference:
 *   J. H. Collier, L. Allison, A. M. Lesk, P.J. Stuckey,
 *   M. Garcia de la Banda, A. S. Konagurthu.
 *   Bioinformatics 33(7):1005-1013, 2017.
 *
 * MMLigner is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MMLigner is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MMLigner. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef DICTCLASS_H
#define DICTCLASS_H
#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cassert>
#include <string>
#include <sstream>
#include <stdint.h>
#include <vector>
#include <stdint.h>
#include <math.h>
#include "mml_newest.h"

using namespace std;
class dictClass_t {
private:
   vector<vector<vector<float> > > dictElem ; // raw coords of all dictElems (frags)
   double dictionaryMsgLen ; // msglen to state the ENTIRE dictionary 
   vector<double> dictElemMsgLen ; // msglen of each of the dictionary elements
   vector<vector<size_t> >  dictElemLegend ; // loci of each frag in dictElem
   size_t nDictElem;

   void erase( const size_t ) ;
   void pop_back() ;
   bool msgLenSanityCheck() ;
   public:
   dictClass_t() ;
   void add( const vector<vector<float> > &, const vector<size_t> &) ;
   void remove( const size_t ) ;
   void swap( const vector<vector<float> > &, const vector<size_t> &, const size_t ) ;
   double getDictionaryMsgLen() ;
   size_t size() ;
   size_t pickRandElem(vector<vector<float> > &, vector<size_t> &);
   void printLegend(vector<string> &) ;
   void printDictElemLegend(vector<string> &, size_t) ;
   void printLastElemLegend(vector<string> &) ;
};
#endif
