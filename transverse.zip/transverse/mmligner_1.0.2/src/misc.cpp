/* Some useful functions
 * Copyright (C) 2017 Laboratory of Computational Biology, Monash University
 * (http://lcb.infotech.monash.edu.au)
 *
 * Reference:
 *   J. H. Collier, L. Allison, A. M. Lesk, P.J. Stuckey,
 *   M. Garcia de la Banda, A. S. Konagurthu.
 *   Bioinformatics 33(7):1005-1013, 2017.
 *
 * MMLigner is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MMLigner is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MMLigner. If not, see <http://www.gnu.org/licenses/>.
 */

#include "misc.h"
vector<double> doubleArray2VectorOfDouble(double arr[], size_t n) {
   vector<double> vec(n);
   for (size_t i = 0; i < n; i++) {
      vec[i] = arr[i];
   }
   return vec;
}

float SSMScore(size_t Ne, size_t str1size, size_t str2size, float rmsd) {
  return (float)pow(static_cast<float>(Ne),2.0f)/(str1size*str2size*(1+pow(rmsd/3,2)));
}

float TopofitScore(size_t Ne, float rmsd) { //modified to remove the 1.7 offset
   float score = 0.25*Ne*exp(-0.39*rmsd*rmsd);
   return score;
}


float combinatorialSSMScore(
  size_t Ne, 
  size_t str1size, 
  size_t str2size, 
  float  rmsd, 
  size_t multiplier 
) {
   float score = (float)pow(static_cast<float>(Ne),2.0f)/(str1size*str2size*(1+pow(rmsd/3,2)));
   return (float)(multiplier*score);
}

float combinatorialTopofitScore(
  size_t Ne, 
  float  rmsd, 
  size_t multiplier 
) {
   float score = 0.25*Ne*exp(-0.39*rmsd*rmsd);
   return (float)(multiplier*score);
}



float adHocScore(size_t Ne, float rmsd) {
   return pow(static_cast<float>(Ne),2.0f)/((1+pow(rmsd/3,2)));
}

size_t choose(size_t n, size_t k) {
   if (k == 0 ) return 1;
   return (n*choose(n-1,k-1))/k;
}

size_t choose2(size_t n) {
   if (n < 2)  return 1;
   return n*(n-1)/2;
}

size_t choose3(size_t n) {
   if (n < 3)  return 1;
   return n*(n-1)*(n-2)/6;
}

string canonicalizefsa(string &s) {
   string cs;

   size_t nI = 0, nD = 0;
   for (size_t i = 0; i < s.length();i++) {
      if (s[i] == 'm') {
         cs.append(nI,'i');
         cs.append(nD,'d');
         cs.push_back('m');
         nI = nD = 0; 
      }
      else if (s[i] == 'i') nI++;
      else if(s[i] == 'd') nD++;
      else if(s[i] == '|') continue; //do nothing -- hinge point
      else {
          cout << s << endl;
          cout << s[i] << endl;
          assert(0);
      }
   }
   cs.append(nI,'i');
   cs.append(nD,'d');
   return cs;
}

size_t getnMatches( string fsastr ) {
  size_t scntr = 0, tcntr = 0, nMatches = 0 ;
  for (size_t i = 0; i < fsastr.length(); i++) {
    if(fsastr[i] == 'm') {
      scntr++;
      tcntr++;
      nMatches++;
    }
  } 
  return nMatches;
}

double getRMSD(
  string fsastr, 
  vector<vector<double> > S, //moving set 
  vector<vector<double> > T  //fixed set
) {
  //identify all matched coordinates
  size_t scntr = 0, tcntr = 0, nMatches = 0 ;
  vector<vector<double> > mS;
  vector<vector<double> > mT;
  for (size_t i = 0; i < fsastr.length(); i++) {
    if(fsastr[i] == 'm') {
      mS.push_back(S[scntr]);
      mT.push_back(T[tcntr]);
      scntr++;
      tcntr++;
      nMatches++;
    }
  } 
  if (nMatches < 3) return 10; //some large rmsd
  Superpose3DClass supobj(mT,mS);
  float rmsd = supobj.getRMSD();
  return rmsd;
}

size_t getnMatchBlocks(string fsastr) {
    size_t nMatchBlocks = 0;
    size_t pos = 0;
    while (pos < fsastr.length()) {
        if (fsastr[pos] != 'm') {
            pos++;
            continue;
        }
        else {
            assert (fsastr[pos] == 'm');
            nMatchBlocks++;
            while(fsastr[pos] == 'm' && pos < fsastr.length()) {
                pos++;
            }
        }
    }
    return nMatchBlocks;
}

size_t getnRigidBlocks(string fsastr) {
  size_t nR = 1 ;
  for (size_t i = 0; i < fsastr.length(); i++) {
    if(fsastr[i] == '|') {
      nR++;
    }
  } 
  return nR;
}

size_t getnHinges(string fsastr) {
  size_t nH = 0 ;
  for (size_t i = 0; i < fsastr.length(); i++) {
    if(fsastr[i] == '|') {
      nH++;
    }
  } 
  return nH;
}


vector<int> getHingePositions(string fsastr) {
  vector<int> pos;
  for (size_t i = 0; i < fsastr.length(); i++) {
    if(fsastr[i] == '|') {
      pos.push_back(i);
    }
  } 
  return pos;
}

double superposeTonSUsingAlignment(
  string fsastr, 
  vector<vector<double> > &S, //fixed set 
  vector<vector<double> > &T  //moving set
) {
    vector<vector<double> > transformedT;
    vector<vector<double> > mS;
    vector<vector<double> > mT;
    size_t scntr = 0, tcntr = 0, nMatches = 0 ;
    for (size_t i = 0; i < fsastr.size(); i++ ) {
        if(fsastr[i] == 'm') {
          mS.push_back(S[scntr]);
          mT.push_back(T[tcntr]);
          transformedT.push_back(T[tcntr]);
          scntr++;
          tcntr++;
          nMatches++;
        }
        else if(fsastr[i] == 'i') {
          transformedT.push_back(T[tcntr]);
          tcntr++;
        }
        else if(fsastr[i] == 'd') {
          scntr++;
        }
        else {
            assert(1);
        }
    }
    if (nMatches < 3) return 0;
    assert(scntr == S.size());
    assert(tcntr == T.size());
    assert(T.size() == transformedT.size());
    Superpose3DClass supobj(mT,mS);
    double rmsd = supobj.getRMSD();
    supobj.transformVectors(T);
    return rmsd;
}

bool sanityCheckAlignment(
 string fsastr,
 vector<vector<double> > S,
 vector<vector<double> > T) {
  if (fsastr.length()==0) return true;
  size_t scntr = 0, tcntr = 0, nMatches = 0 ;
  for (size_t i = 0; i < fsastr.length(); i++) {
    if(fsastr[i] == 'm') {
      scntr++;
      tcntr++;
      nMatches++;
    }
    else if(fsastr[i] == 'i') {
      tcntr++;
    }
    else if(fsastr[i] == 'd') {
      scntr++;
    }
    else if(fsastr[i] == '|') {
        continue;
    }
    else {
        assert(1);
    }
  }
  //cout << scntr << " " << tcntr << " " << S.size() << " " <<  T.size() << endl;
  if(scntr==S.size() && tcntr==T.size()) return true;
  else return false;
}


/* Convert double vector to double array */
void dv2da(vector<double> &vec, double arr[3]){
   assert(vec.size()==3);
   arr[0] = vec[0];
   arr[1] = vec[1];
   arr[2] = vec[2];
}

/* Convert double array to double vector */
void da2dv(double arr[3], vector<double> &vec) {
   assert(vec.size()==3);
   vec[0] = arr[0];
   vec[1] = arr[1];
   vec[2] = arr[2];
}

string getFilenameFromPath (const char *str) {
    string path = str;
    string fname;
    size_t found = path.find_last_of("/\\");
    return  path.substr(found+1);
}

double nits2bits(double x) {
    return x/log(2);
}

double bits2nits(double x) {
    return x*log(2);
}



void writeAlignmentStatsToFile(vector<double> &algnstats, string fname, bool kramaflag) {
    ofstream out(fname.c_str(),ios::out);
    assert(out);

    out << "Structure Sizes =   " ;
    if (kramaflag == false) {
      out << (size_t)algnstats[ALIGNSTATS_IDX_NS] << " "
	  << (size_t)algnstats[ALIGNSTATS_IDX_NT] << endl;
    } else {
      out << (size_t)algnstats[ALIGNSTATS_IDX_NT] << " "
	  << (size_t)algnstats[ALIGNSTATS_IDX_NS] << endl;
    }
    out << "Coverage        =   " << left
	<< setw(9) << algnstats[ALIGNSTATS_IDX_NMATCH] << endl;
    out << "RMSD            = " << right
	<< setw(9) << algnstats[ALIGNSTATS_IDX_RMSD]  << " A" << endl;
    out << "I(A)            = " << right
	<< setw(9) << nits2bits(algnstats[ALIGNSTATS_IDX_IA])
	<< " bits" << endl;
    out << "NULL(S & T)     = " << right
	<< setw(9) << nits2bits(algnstats[ALIGNSTATS_IDX_NULLST])
	<< " bits" << endl;
    out << "I(A & <S,T>)    = " << right
	<< setw(9) << nits2bits(algnstats[ALIGNSTATS_IDX_IVALUE])
	<< " bits" << endl;

    out << "Compression     = " << right
	<< setw(9) << nits2bits(algnstats[ALIGNSTATS_IDX_COMPRESSION])
	<< " bits (+ve better; -ve worse)" << endl;
    out.close();
}

void printToTerminalMsg(ostringstream &os) {
    cout << left << setw(50) << os.str() << flush;
}

void printToTerminalMsgStatus(string s) {
    cout << "[ \033[32;4m" << s << "\033[0m ]" << endl;
}

void printToTerminalMsgStatus_wo_newline(string s) {
    cout << "[ \033[32;4m" << s << "\033[0m ]";
}

string getTerminalColorString(string s,size_t color) {
    ostringstream oss;
    oss << " \033["<< color<<";4m" << s << "\033[0m " ;
    return oss.str();
}

void printPercentCompleted(size_t num, size_t denom, size_t width, size_t nBackspaces) {
    for (size_t i = 0; i < nBackspaces; i++) cout << "\b \b";
    cout << setw(width) << fixed << setprecision(3) << (float)(num)*100/(float)denom << '%'  << flush;
}

