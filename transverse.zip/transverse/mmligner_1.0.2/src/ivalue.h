/* I-value implementation
 * Copyright (C) 2017 Laboratory of Computational Biology, Monash University
 * (http://lcb.infotech.monash.edu.au)
 *
 * Reference:
 *   J. H. Collier, L. Allison, A. M. Lesk, P.J. Stuckey,
 *   M. Garcia de la Banda, A. S. Konagurthu.
 *   Bioinformatics 33(7):1005-1013, 2017.
 *
 * MMLigner is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MMLigner is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MMLigner. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef IVALUE_CPP
#define IVALUE_CPP

#include <iostream>
#include <vector>
#include <cstdlib>
#include <limits>

#include "mmligner_config.h"
#include "Kent.h"
#include "misc.h"
#include "geometry3D.h"
#include "superpose3D.h"

double nits2bits(double);
double bits2nits(double);
double logStarNew_bits(const size_t);
double negLogProbNormalDist(const double,const double,const double, double );    
double negLogProbUniformDirection(const double, const double);


class CACoordinateEncoding_t {
    private:
        size_t dim;
        vector<vector<double> > kent_likelihoods; 
        vector<double> IThetaPhi; 
        vector<double> Iradius; 
    public:
        CACoordinateEncoding_t(vector<vector<double> > C, KentMixtureModel &);
        double getIThetaPhiRadius(size_t); // of one coordinate
        double getIThetaPhiRadius();       // of the entire chain.
        double getNullModelMessageLength(); //same as above + len enc
        vector<double> getComponentLikelihoods(size_t );
        double getIThetaPhi(size_t);
        double getIRadius(size_t);
        double getReweightedIThetaPhiRadius(size_t,vector<double>&, KentMixtureModel &);
};

/**
 * Returns a vector containing alignment data
    algnstats.push_back(IAST);    //[0]  IValue
    algnstats.push_back(NULLS);   //[1]  Null of S
    algnstats.push_back(NULLT);   //[2]  Null of T
    algnstats.push_back(IA);      //[3]  IA
    algnstats.push_back(rITgSA);  //[4]  rITgSA
    algnstats.push_back(diff);    //[5]  compression
    algnstats.push_back(NULLST);  //[6]  Null of S & T
    algnstats.push_back(nMatches);//[7]  nMatches
    algnstats.push_back(rmsd);    //[8]  rmsd 
    algnstats.push_back(S.size());//[9]  S.size()
    algnstats.push_back(T.size());//[10] T.size()
*/
vector<double> computeIvalue(string, vector<vector<double> >, vector<vector<double> >, bool); 
#endif
