/* Defines a command line interface and an API for reading argv
 * Copyright (C) 2017 Laboratory of Computational Biology, Monash University
 * (http://lcb.infotech.monash.edu.au)
 *
 * Reference:
 *   J. H. Collier, L. Allison, A. M. Lesk, P.J. Stuckey,
 *   M. Garcia de la Banda, A. S. Konagurthu.
 *   Bioinformatics 33(7):1005-1013, 2017.
 *
 * MMLigner is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MMLigner is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MMLigner. If not, see <http://www.gnu.org/licenses/>.
 */

#include "cmdLineParser.h"

bool doesFileExist(string fname) {

    const char *fn  = fname.c_str();
    ifstream infile(fn,ios::in);
    return infile.good();
}

/* Pretty LAME cmdline parser */
void parseCmdLine( 
  int nargs, 
  char *args[],
  vector<string> &structFileNames,
  vector<string> &structChainIDs,
  bool &param_ivalue,
  string &param_fasta_fname,
  bool &param_superposed_pdb,
  string &param_output_prefix_string
) {
    bool continueflag = true ;
    multimap<string,string> myMap;

    string currentSwitch = "-pdb";
    for( int i = 1 ; i <  nargs ; i++ ) {
        if( args[i][0]== '-' ) {
            currentSwitch.clear();
            if( strcmp(args[i],"--ivalue") == 0 ) {
                param_ivalue = true ;
                currentSwitch.assign( args[i] ) ;
            }
            else if( strcmp(args[i],"--superpose") == 0 ) {
                param_superposed_pdb = true ;
            }
            else if( strcmp(args[i],"-o") == 0 ) {
                currentSwitch.assign( args[i] ) ;
            }
            else  {
                cerr << "::CmdLineError:: Unsupported option: " 
                    << args[i] << endl ;
                continueflag = false ;
                currentSwitch.assign("-X");
            }
        }
        else{
            myMap.insert( pair<string, string>(currentSwitch,args[i])) ;
        }   
    }
    if(param_ivalue == true && myMap.count("--ivalue") != 1) {
        cerr << "::CmdLineError:: Option \'--ivalue\' takes an alignment fasta file as an argument\n" ;
        continueflag = false;
    }

    if(myMap.count("-pdb") != 2) {
        cerr << "::CmdLineError:: " << "MMLigner takes two structures (in PDB format) as arguments\n";
        continueflag = false;
    }

    if(myMap.count("-o") > 1) {
        cerr << "::CmdLineError:: Option \'-o\' takes one output_prefix_string as an argument\n";
        continueflag = false;
    }

    if(myMap.count("-X") > 0 ) {
        cerr << "::CmdLineError:: The following arguments cannot be processed:\n" ;
        pair<multimap<string, string>::iterator, multimap<string, string>::iterator> range;
        range = myMap.equal_range("-X");

        /* Loop through range of maps of key "-X" */
        for (multimap<string, string>::iterator itr = range.first;
                     itr != range.second;
             ++itr) {
                cerr << "                  " << (*itr).second << endl;
        }
        continueflag = false;
    }

    //dissect fname:chainids strings from arguments
    if(myMap.count("-pdb") == 2 ) {
        pair<multimap<string, string>::iterator, multimap<string, string>::iterator> range;
        range = myMap.equal_range("-pdb");

        /* Loop through range of maps of key "-pdb" */
        multimap<string, string>::iterator itr;
        for (itr = range.first; itr != range.second; ++itr) {
            string structPlusChain = (*itr).second;
            size_t pos = structPlusChain.find(":");
            string fname;
            string chainids;
            if (pos == string::npos) {
                fname = structPlusChain; 
            }
            else{
                fname = structPlusChain.substr(0,pos);
                pos++;
                chainids = structPlusChain.substr(pos,structPlusChain.length());
            }
            if (!doesFileExist(fname)) {
                cerr << "::CmdLineError:: File '" << fname << "' does not exist\n" ;
                continueflag = false;
            }
            structFileNames.push_back(fname);
            structChainIDs.push_back(chainids);
        }
    }

    //assign fasta fname
    if(myMap.count("--ivalue") == 1 ) {
        pair<multimap<string, string>::iterator, multimap<string, string>::iterator> range;
        range = myMap.equal_range("--ivalue");

        /* Loop through range of maps of key "--ivalue" */
        multimap<string, string>::iterator itr;
        for (itr = range.first; itr != range.second; ++itr) {
            param_fasta_fname = (*itr).second;
            if (!doesFileExist(param_fasta_fname)) {
                cerr << "::CmdLineError:: File '" << param_fasta_fname << "' does not exist\n" ;
                continueflag = false;
            }
        }
    }

    if(continueflag == false || nargs < 2 ) {
        cerr  << "    Usage: " << "mmligner <pdb1>(:<chainIDs>) <pdb2>(:<chainIDs)\n";
        cerr  << "           " << "           (--ivalue <fasta>)\n";
        cerr  << "           " << "           ( -o  <output_prefix_string>) \n";
        cerr  << "           " << "           ( --superpose) \n\n";
        exit(1) ;
    }
    assert(structFileNames.size() == 2);
    assert(structChainIDs.size() == 2);


    //assign output_prefix_string
    if(myMap.count("-o") == 1 ) {
        pair<multimap<string, string>::iterator, multimap<string, string>::iterator> range;
        range = myMap.equal_range("-o");

        /* Loop through range of maps of key "-s" */
        multimap<string, string>::iterator itr;
        for (itr = range.first; itr != range.second; ++itr) {
            param_output_prefix_string = (*itr).second;
        }
    }
    else {
        string outPrefixString;
        outPrefixString.append(getFilenameFromPath(structFileNames[0].c_str()));
        outPrefixString += "_vs_";
        outPrefixString.append(getFilenameFromPath(structFileNames[1].c_str()));
        param_output_prefix_string = outPrefixString;
    }

}


