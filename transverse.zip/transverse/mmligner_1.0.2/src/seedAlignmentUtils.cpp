/* Interface for generating seed alignments
 * Copyright (C) 2017 Laboratory of Computational Biology, Monash University
 * (http://lcb.infotech.monash.edu.au)
 *
 * Reference:
 *   J. H. Collier, L. Allison, A. M. Lesk, P.J. Stuckey,
 *   M. Garcia de la Banda, A. S. Konagurthu.
 *   Bioinformatics 33(7):1005-1013, 2017.
 *
 * MMLigner is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MMLigner is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MMLigner. If not, see <http://www.gnu.org/licenses/>.
 */

#include "mmligner_config.h"
#include "seedAlignmentUtils.h"

#define MFP_MAX_RMSD_THRESH  2
#define MFP_MIN_LEN 5 

#define RMSD_THRESHOLD_PAIR 2 
#define RMSD_THRESHOLD_TRIPLE 3 
#define RMSD_THRESHOLD_CLUSTERING 3 
#define MEMBERSHIP_THRESHOLD 0.2


vector<vector<float> > tripletMFPWeighting(MFPLibraryClass_t mfplibobj) {
   const size_t MIN_TRIPLE_LEN = 3*MFP_MIN_LEN;
   //const size_t MIN_DOUBLE_LEN = 3*MFP_MIN_LEN;
   const size_t ssize1 = mfplibobj.strsize[0];
   const size_t ssize2 = mfplibobj.strsize[1];
   vector<vector<float> > w;
   for (size_t i = 0 ; i < ssize1; i++) {
      w.push_back(vector<float>(ssize2,0));
   }
   vector<MFPClass_t> mfp = mfplibobj.getMFPLibrary();
   size_t nMFPs = mfp.size();
   size_t MINGAP = 0;
   size_t ncomb = (nMFPs*(nMFPs-1))/2;

   //set liberal pair thresholds if nMFPs is small
   if (nMFPs < 100) {
    #undef RMSD_THRESHOLD_PAIR
    #define RMSD_THRESHOLD_PAIR 2.5 
   }

   size_t cntr = 0;
   for (size_t i = 0; i < nMFPs; i++) {
      size_t      len_i = mfp[i].length;
      size_t       sp11 = mfp[i].locus[0];
      size_t       ep11 = mfp[i].locus[0]+len_i-1;
      size_t       sp12 = mfp[i].locus[1];
      size_t       ep12 = mfp[i].locus[1]+len_i-1;
      SuffStatClass ss1 = mfp[i].supobj.getSufficientStatistics();
      //populate score if mfp as computed in MFPClass 
      float score = mfp[i].score/MIN_TRIPLE_LEN;
      for (size_t l = 0; l < len_i; l++) {
         w[sp11+l][sp12+l] += score; 
      }
      for (size_t j = i+1; j < nMFPs; j++) {
         cntr++;
         size_t      len_j = mfp[j].length;
         size_t       sp21 = mfp[j].locus[0];
         size_t       ep21 = mfp[j].locus[0]+len_j-1;
         size_t       sp22 = mfp[j].locus[1];
         size_t       ep22 = mfp[j].locus[1]+len_j-1;
         SuffStatClass ss2 = mfp[j].supobj.getSufficientStatistics();
 
         //check if two MFPs overlap; disallow them if yes.
         bool goaheadflag = false;
         if (ep11 < sp21-MINGAP && ep12 < sp22-MINGAP) goaheadflag = true;
         if (!goaheadflag) continue;

         Superpose3DClass supobj12(ss1,ss2,'+');
         double rmsd = supobj12.getRMSD();
         if (rmsd > RMSD_THRESHOLD_PAIR) continue;
         
         size_t len_ij = len_i + len_j;
         //populate score if mfp pair is beyond a certain length
         if (nMFPs<100 || len_ij >= MIN_TRIPLE_LEN
                 || mfp[i].coverage[0]+mfp[j].coverage[0] > 0.4
                 || mfp[i].coverage[1]+mfp[j].coverage[1] > 0.4
         ) {
             //cout <<  mfp[i].coverage[0]+mfp[j].coverage[0] << endl;
             //cout <<  mfp[i].coverage[1]+mfp[j].coverage[1] << endl;
            size_t nTilesi = ceil((float)len_i/MFP_MIN_LEN);
            size_t nTilesj = ceil((float)len_j/MFP_MIN_LEN);
            size_t scoremultiplier =   choose2(nTilesi)*nTilesj 
                                     + choose2(nTilesj)*nTilesi ;

            float score = combinatorialTopofitScore(3*MFP_MIN_LEN,rmsd,scoremultiplier);
            score /= MIN_TRIPLE_LEN;
            //cout << nTilesi << " " << nTilesj << " " << score << endl << endl;
            for (size_t l = 0; l < len_i; l++) {
               w[sp11+l][sp12+l] += score; 
            }
            for (size_t l = 0; l < len_j; l++) {
               w[sp21+l][sp22+l] += score; 
            }
         }

         SuffStatClass ss12 = supobj12.getSufficientStatistics();
         for (size_t k = j+1; k < nMFPs; k++) {
            size_t len_k       = mfp[k].length;
            size_t sp31        = mfp[k].locus[0];
            //size_t ep31        = mfp[k].locus[0]+len_k-1;
            size_t sp32        = mfp[k].locus[1];
            //size_t ep32        = mfp[k].locus[1]+len_k-1;
            SuffStatClass ss3  = mfp[k].supobj.getSufficientStatistics();
            
            bool goaheadflag2 = false;
            if (ep21 < sp31-MINGAP && ep22 < sp32-MINGAP) goaheadflag2 = true;
            if (!goaheadflag2) continue;
            
            Superpose3DClass supobj123(ss12,ss3,'+');
            double rmsd = supobj123.getRMSD();
            if (rmsd > RMSD_THRESHOLD_TRIPLE) continue;
 
            //size_t len_ijk = len_i+len_j+len_k;
            //assert(len_i>=MFP_MIN_LEN&&len_j>=MFP_MIN_LEN&&len_k>=MFP_MIN_LEN);
            size_t nTilesi = ceil((float)len_i/MFP_MIN_LEN);
            size_t nTilesj = ceil((float)len_j/MFP_MIN_LEN);
            size_t nTilesk = ceil((float)len_k/MFP_MIN_LEN);

            size_t scoremultiplier =   choose2(nTilesi)*nTilesj 
                                     + choose2(nTilesi)*nTilesk 
                                     + choose2(nTilesj)*nTilesi 
                                     + choose2(nTilesj)*nTilesk 
                                     + choose2(nTilesk)*nTilesi 
                                     + choose2(nTilesk)*nTilesj
                                     + (nTilesi*nTilesj*nTilesk);
            float score = combinatorialTopofitScore(3*MFP_MIN_LEN,rmsd,scoremultiplier);
            score /= MIN_TRIPLE_LEN;

            //populate scores
            for (size_t l = 0; l < len_i; l++) {
               w[sp11+l][sp12+l] += score; 
            }
            for (size_t l = 0; l < len_j; l++) {
               w[sp21+l][sp22+l] += score; 
            }

            for (size_t l = 0; l < len_k; l++) {
               w[sp31+l][sp32+l] += score; 
            }
            
            if (cntr == 0) printPercentCompleted(cntr++,ncomb,8,0);
            if (cntr%10 == 0) printPercentCompleted(cntr++,ncomb,8,9);
         }
      }
   }
   printPercentCompleted(ncomb,ncomb,8,9);
   return w;
}



void barZeroWeightCells( vector<vector<float> > &w) {
   size_t rows = w.size();
   size_t cols = w[0].size();

   for (size_t i = 0 ; i < rows; i++) {
      for (size_t j = 0; j < cols; j++) {
         if (w[i][j] == 0) w[i][j] = -99999;
      }
   }

}


vector<MFPClass_t> identifyFilteredMFPs(
  vector<MFPClass_t> &mfps, 
  vector<vector<float> > &w
) {
   if (mfps.size() < 100) return mfps;
   float maxval = 0;
   for (size_t i = 0; i < w.size(); i++) {
      for (size_t j = 0; j < w[0].size(); j++) {
         if (w[i][j] > maxval) maxval = w[i][j];
      }
   }

   vector<MFPClass_t> promisingMFPs;

   for (size_t i = 0; i < mfps.size(); i++) {
      size_t sp1 = mfps[i].locus[0];
      size_t sp2 = mfps[i].locus[1];
      bool flag = false;
      for (size_t l = 0; l < mfps[i].length; l++) {
         //3% threshold
         if (w[sp1+l][sp2+l]>0.03*maxval) {
            flag = true;
            break;
         }
      }
      if (flag == true) promisingMFPs.push_back(mfps[i]); 
   }
   return promisingMFPs;
}


void sortByLociMFPs(vector<vector<MFPClass_t> > &mfpsclust) {

  for (size_t c = 0;  c < mfpsclust.size(); c++) {
    for (size_t i = 1; i < mfpsclust[c].size(); i++) {
      MFPClass_t key_i = mfpsclust[c][i];
      ssize_t j = i-1;
      while(j >=0 
            && (  (mfpsclust[c][j].locus[0]>key_i.locus[0]) 
                ||(mfpsclust[c][j].locus[0]== key_i.locus[0] 
                    && 
                   mfpsclust[c][j].locus[1] >  key_i.locus[1]
                   )
                )
           ){
         mfpsclust[c][j+1] = mfpsclust[c][j];
         j--;
      }
      mfpsclust[c][j+1] =  key_i;
    }
  }

   if(VERBOSE) { 
       cout << "Sorted MFPs (on Loci)\n";
       for (size_t c = 0;  c < mfpsclust.size(); c++) {
           cout  << "Cluster " << c << " ----------------"<< endl;
         for (size_t i = 0; i < mfpsclust[c].size(); i++) {
            cout << mfpsclust[c][i].locus[0] << " " 
                << mfpsclust[c][i].locus[1] << " " 
                << mfpsclust[c][i].length << " " 
                << mfpsclust[c][i].score << endl;
         }
       }
   }
}

void sortDecreasingByLengthMFPs(vector<MFPClass_t> &mfps) {
   for (size_t i = 1; i < mfps.size(); i++) {
      MFPClass_t key_i = mfps[i];
      ssize_t j = i-1;
      while(j >=0 && mfps[j].length <  key_i.length) {
         mfps[j+1] = mfps[j];
         j--;
      }
      mfps[j+1] =  key_i;
   }

   if (VERBOSE) {
       cout << "Sorted MFPs (by length)\n";
       for (size_t i = 0; i < mfps.size(); i++) {
            cout << mfps[i].locus[0] << " " << mfps[i].locus[1] 
                << " " << mfps[i].length << " " << mfps[i].score << endl;
        }
   }
}

void sortClustersDecreasingByFootprint(
 vector<vector<MFPClass_t> > &clusters,
 vector<size_t> &clusters_fp
) {
   assert (clusters.size() == clusters_fp.size());
   for (size_t i = 1; i < clusters.size(); i++) {
      size_t key_i_fp = clusters_fp[i];
      vector<MFPClass_t> key_i_cl  = clusters[i];
      ssize_t j = i-1;
      while(j >=0 && clusters_fp[j] <  key_i_fp) {
         clusters_fp[j+1] = clusters_fp[j];
         clusters[j+1] = clusters[j];
         j--;
      }
      clusters_fp[j+1] =  key_i_fp;
      clusters[j+1] =  key_i_cl;
   }
}

vector<vector<MFPClass_t> > clusterMFPs(
 vector<MFPClass_t> &mfps,
 vector<size_t> &clusters_footprint
) {
   vector<vector<MFPClass_t> > clusters;
   if (mfps.size() == 0) return clusters;

   vector<MFPClass_t> cl;
   cl.push_back(mfps[0]);
   clusters.push_back(cl);
   clusters_footprint.push_back(mfps[0].length);

   for (size_t i = 1 ; i < mfps.size(); i++) {
      if (VERBOSE) {
            cout << "Assigning cluster for " << mfps[i].locus[0] << " " 
                << mfps[i].locus[1] << " " << mfps[i].length  << "\n";
      }
      bool membershipflag = false;
      for (size_t c = 0; c < clusters.size(); c++) {
         size_t nHits = 0;
         for (size_t j = 0; j < clusters[c].size(); j++) {
            //does mfps[i] fits within an rmsd thresh with clust mem          
            SuffStatClass ss1 = mfps[i].supobj.getSufficientStatistics();
            SuffStatClass ss2 = clusters[c][j].supobj.getSufficientStatistics();
            Superpose3DClass supobj(ss1,ss2,'+');
            if (supobj.getRMSD() < RMSD_THRESHOLD_CLUSTERING) nHits++;
         }
         if (VERBOSE) {
            cout << "\t| clust " << c 
                << " clust size " << clusters[c].size()
                << " nhits " << nHits
                << " hitrate = " << (float)nHits/clusters[c].size() << endl;  
         }
         if ((float)nHits/clusters[c].size() > MEMBERSHIP_THRESHOLD) {
            membershipflag = true;
            clusters[c].push_back(mfps[i]);
            clusters_footprint[c] += mfps[i].length;
            break;
         }
      }
      if (membershipflag == false) {
         vector<MFPClass_t> clnew;
         clnew.push_back(mfps[i]);
         clusters.push_back(clnew);
         clusters_footprint.push_back(mfps[i].length);
      }
   }
   sortClustersDecreasingByFootprint(clusters,clusters_footprint);
   return clusters;
}

vector<bool> clusterValidityBitmask(
 vector<size_t> &fp,
 size_t strsize1,
 size_t strsize2
) {
    //cout << endl;

    vector<bool> bitmask(fp.size(),false);
    for (size_t c = 0;  c < fp.size(); c++) {
        float cov1 = (float)fp[c]/(float)strsize1;
        float cov2 = (float)fp[c]/(float)strsize2;
        //cout << "cluster " << c << " residue coverage = " << cov1 << " " << cov2 << endl;
        //cout << "\t" << fp[c] << " " << strsize1 << " " << strsize2 << endl;
        if (cov1 > 0.25 && cov2 > 0.25) bitmask[c] = true;
    }
    return bitmask;
}

vector<string> generateSeedAlignments(
 structureInformationClass &struct_S, 
 structureInformationClass &struct_T
) {
    vector<string> seedfsastrings;

    MFPLibraryClass_t mfplibobj;
    for (size_t i = 0; i < 15; i++) {
        MFPLibraryClass_t tmp_mfplibobj(struct_S,struct_T,
                MFP_MAX_RMSD_THRESH,MFP_MIN_LEN+i,"RMSD_VARYING");
        if (tmp_mfplibobj.getMFPLibrarySize() <= 5000) {
           mfplibobj = tmp_mfplibobj;
           break;
        }
    }
    if (mfplibobj.getMFPLibrarySize() == 0) {
        string fsastr = getUnalignedFSAString(struct_S.size,struct_T.size);
        seedfsastrings.push_back(fsastr);
        return seedfsastrings;
    }

    ostringstream oss;
    oss << "...filtering MFP library ";
    printToTerminalMsg(oss);
    cout << setw(15) << " " ;
    vector<vector<float> > w = tripletMFPWeighting(mfplibobj);
    barZeroWeightCells(w);
    vector<MFPClass_t> mfps = mfplibobj.getMFPLibrary();
    vector<MFPClass_t> filteredMFPs;
    if (mfps.size() > 100) filteredMFPs = identifyFilteredMFPs(mfps,w);
    else filteredMFPs = mfps;
    printToTerminalMsgStatus("OK");
    if (VERBOSE) {
      cout << "Subset MFP lib size = " << filteredMFPs.size() << endl;
      cout << "Full   MFP lib size = " << mfps.size() << endl;
      cout << "Reduction factor by   " << (float)filteredMFPs.size()/mfps.size() << endl;
    }

    oss.str("");
    oss.clear();
    oss << "...clustering filtered MFP library ";
    printToTerminalMsg(oss);
    cout << setw(15) << " " ;
    sortDecreasingByLengthMFPs(filteredMFPs);
    vector<size_t> clusters_footprint;
    vector<vector<MFPClass_t> > clusters;
    vector<bool> clusters_bitmask;
    if (filteredMFPs.size() >100) {
        clusters = clusterMFPs(filteredMFPs,clusters_footprint);
        assert(clusters.size() == clusters_footprint.size());
        if (VERBOSE) cout << "nClusters = " << clusters.size() << endl;;
        clusters_bitmask = clusterValidityBitmask(clusters_footprint,struct_S.size, struct_T.size);
    }
    else {
        clusters.push_back(filteredMFPs);
        assert(clusters.size()==1);
        clusters_bitmask.push_back(true);
    }
    sortByLociMFPs(clusters);
    printToTerminalMsgStatus("OK");

    oss.str("");
    oss.clear();
    oss << "...generating seed alignments ";
    printToTerminalMsg(oss);
    cout << setw(15) << " " ;
    for (size_t c = 0; c < clusters.size(); c++) {
        if (clusters_bitmask[c] == false) continue;
        if (VERBOSE) {
            cout << "Cluster " << c+1 << endl;
            for (size_t j = 0; j < clusters[c].size(); j++) {
                cout << "\t" << clusters[c][j].locus[0] << " ";
                cout << clusters[c][j].locus[1] << " ";
                cout << clusters[c][j].length << endl;
            }
        }

        MFPLibraryClass_t clust_mfplibobj(clusters[c],
                                            struct_S.size,struct_T.size);
        vector<vector<float> > clust_w = tripletMFPWeighting(clust_mfplibobj);
        barZeroWeightCells(clust_w);

        AlignClass_t clust_algn(clust_w);
        vector<vector<float> > clust_dpmat = clust_algn.getDPMatrix();
        string clust_optfsa = clust_algn.getFSAString();
        size_t nM = getnMatches(clust_optfsa);
        double cov1 = (double)nM/struct_S.size;
        double cov2 = (double)nM/struct_T.size;
        double thresh = (c <5)?0.2:0.5;
        if (cov1 >thresh||cov2>thresh) {
            seedfsastrings.push_back(clust_optfsa);
        }
    }
    printToTerminalMsgStatus_wo_newline("OK");
    cout << " " << seedfsastrings.size();
    if (seedfsastrings.size() > 1) cout << " seeds" << endl;
    else cout << " seed" << endl;
    return seedfsastrings;
}
