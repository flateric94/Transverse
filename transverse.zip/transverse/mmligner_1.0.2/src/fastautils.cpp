/* Defines an interface for reading and writing FASTA files
 * Copyright (C) 2017 Laboratory of Computational Biology, Monash University
 * (http://lcb.infotech.monash.edu.au)
 *
 * Reference:
 *   J. H. Collier, L. Allison, A. M. Lesk, P.J. Stuckey,
 *   M. Garcia de la Banda, A. S. Konagurthu.
 *   Bioinformatics 33(7):1005-1013, 2017.
 *
 * MMLigner is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MMLigner is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MMLigner. If not, see <http://www.gnu.org/licenses/>.
 */

#include "fastautils.h"
vector<string> readFastaFile(const char *fname) {
    vector<string> algn;
    size_t nmarkups = 0;
    char buff [10000];

    ifstream infile(fname,ios::in);
    assert(infile);
    
    //ignore until line starting with '>'
    while (!infile.eof()) {
        infile.getline(buff,10000);
        if (infile.eof()) break;
        if (buff[0] == '>'){ nmarkups++; break;}
    }
    //read alignment string
    string a1;
    while (!infile.eof()) {
        infile.getline(buff,10000);
        if (infile.eof()) break;
        if (buff[0] == '\0') break;
        if (buff[0] == ' ') break;
        if (buff[0] == '>') { nmarkups++; break;}
        a1 += buff;
    }

    while (buff[0] != '>' && !infile.eof()) {
        infile.getline(buff,10000);
        if (infile.eof()) break;
        if (buff[0] == '>') { nmarkups++; break;}
    }
    //read alignment string
    string a2;
    while (!infile.eof()) {
        infile.getline(buff,10000);
        if (infile.eof()) break;
        if (buff[0] == '\0') break;
        if (buff[0] == ' ') break;
        if (buff[0] == '>') { nmarkups++; break;}
        a2 += buff;
    }
    infile.close();

    algn.push_back(a1);
    algn.push_back(a2);

    assert (algn[0].length() == algn[1].length());
    assert (algn.size() == 2);
    if (nmarkups !=2 || algn[0].length()==0) {
        cerr << "\n::FastaFileError:: The alignement file not in FASTA  format\n";
        cerr << getTerminalColorString("Aborted!",31) << endl;
        
        exit(1);
    }
    return algn;
}

string fastaAlignment2fsa(const char *fname) {
    vector<string> algn = readFastaFile(fname);
    string fsastr;
    size_t ssize=0;
    size_t tsize=0;
    for (size_t i = 0;  i < algn[0].length(); i++) {
        if (algn[0][i] == '|' && algn[1][i] == '|') fsastr.push_back('|');
        else if (algn[0][i] != '-' && algn[1][i] != '-') {
            fsastr.push_back('m');
            ssize++;
            tsize++;
        }
        else if (algn[0][i] != '-' && algn[1][i] == '-') {
            fsastr.push_back('d');
            ssize++;
        }
        else if (algn[0][i] == '-' && algn[1][i] != '-') {
            fsastr.push_back('i');
            tsize++;
        }
    }
    assert (algn[0].length() == fsastr.length());
    assert (algn[1].length() == fsastr.length());
    bool rekramizefasta = false;
    if (ssize < tsize) rekramizefasta = true;
    if(rekramizefasta) {
        for (size_t i = 0;  i < fsastr.length(); i++) {
            if (fsastr[i] == 'i') fsastr[i] = 'd';
            else if (fsastr[i] == 'd') fsastr[i] = 'i';
        }
    }
    return fsastr;
}



vector<string> fsastr2SeqAlignment( string &s, string &aaseq1, string &aaseq2) {
   vector<string> algn(2);
   size_t x = 0, y =0;
   for (size_t i = 0 ; i < s.length(); i++) {
      switch(s[i]) {
         case 'm': algn[0].push_back(aaseq1[x++]);
                   algn[1].push_back(aaseq2[y++]);
                   break;
         case 'd': algn[0].push_back(aaseq1[x++]);
                   algn[1].push_back('-');
                   break;
         case 'i': algn[0].push_back('-');
                   algn[1].push_back(aaseq2[y++]);
                   break;
         default : assert(0);
      }
   }
   return algn;
}

string getUnalignedFSAString(size_t Ssize, size_t Tsize) {
    string fsastr_unaligned;
    for (size_t i = 0; i < Ssize; i++) fsastr_unaligned += 'd';
    for (size_t i = 0; i < Tsize; i++) fsastr_unaligned += 'i';
    return fsastr_unaligned;
}

void writeToFastaFile(vector<string> a, string f) {
   ofstream out(f.c_str(),ios::out);
   assert(out);
   out << "> structure1" << endl;
   out << a[0] << endl << endl;
   out << "> structure2" << endl;
   out << a[1] << endl;

   out.close();
}

void writeToFastaFile(vector<string> a, string f, vector<string> names, bool flag) {
    string a_s,a_t;
   string name_s = names[0], name_t = names[1];
   if (!flag) { 
      a_s = a[0];
      a_t = a[1];
   }
   else {
      a_s = a[1];
      a_t = a[0];
   }
   
   ofstream out(f.c_str(),ios::out);
   assert(out);
   out << "> " << name_s << endl;
   for (size_t i = 0; i < a_s.size(); i++) {
       out << a_s[i];
       if((i+1)%60 == 0) out << "\n";
   }
   if (a_s.size()%60 != 0) out << "\n";
   out << "\n";
   
   out << "> " << name_t << endl;
   for (size_t i = 0; i < a_t.size(); i++) {
       out << a_t[i];
       if((i+1)%60==0) out << "\n";
   }
   if (a_t.size()%60 != 0) out << "\n";
   out.close();
}

