#ifndef _Date_h_
#define _Date_h_

#ifdef __GNUG__
#  pragma interface
#endif

/* put date into string.. */
void Date(char* string);

#endif

