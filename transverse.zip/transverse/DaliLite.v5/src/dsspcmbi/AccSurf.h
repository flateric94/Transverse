#ifndef _AccSurf_h_
#define _AccSurf_h_

#ifdef __GNUG__
#  pragma interface
#endif

void Flagaccess(int order);

#endif

